package com.robben.mands.Adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.robben.mands.Models.CastsModel;
import com.robben.mands.R;
import com.robben.mands.Utils.Helper;

import java.util.List;
import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by Mezioud on  23,août,2021.
 */
public class CastsAdapter extends RecyclerView.Adapter<CastsAdapter.ViewHolder> {

     Context context;
     List<CastsModel> castsModels;
     Helper helper;

    public CastsAdapter(List<CastsModel> castsModels,Context context) {
        this.context = context;
        this.castsModels = castsModels;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_actor, parent, false);

        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {

        helper = new Helper(context);

        Uri mv1 = Uri.parse(castsModels.get(position).getProfile_path());
        String movieCast = mv1.getLastPathSegment();


        Glide.with(holder.itemView)
                .load(helper.getUrlImage()+"/thumb/500x500/uploads/"+movieCast)
                .placeholder(R.drawable.placeholder_profile)
                .into(holder.poster);

        holder.text_view_item_actor_cast.setText(castsModels.get(position).getOriginal_name());



    }

    @Override
    public int getItemCount() {

            return castsModels.size();

    }



    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public TextView text_view_item_actor_cast;
        public CircleImageView poster;
        public ViewHolder(View itemView) {
            super(itemView);

            poster = itemView.findViewById(R.id.circle_image_view_item_actor);
            text_view_item_actor_cast = itemView.findViewById(R.id.text_view_item_actor_cast);
            poster.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int position = getAdapterPosition();
            showPopupMenu(v, position);
        }
    }

    private void showPopupMenu(View v, int position) {

        //Toast.makeText(v.getContext(),castsModels.get(position).getDetails_path(), Toast.LENGTH_LONG).show();

    }

}
