package com.robben.mands.Adapter;

import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Environment;
import android.provider.Browser;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.robben.mands.Dialog.DialogDownload;
import com.robben.mands.Models.StreamModel;
import com.robben.mands.R;
import com.robben.mands.Ui.MainActivityMoviesDetails;

import java.util.List;

public class DownloadAdapter extends RecyclerView.Adapter<DownloadAdapter.ViewHolder> {

    Context context;
    List<StreamModel> streamModels;

    public DownloadAdapter(List<StreamModel> streamModels, Context context) {
        this.context = context;
        this.streamModels = streamModels;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_stream, parent, false);
        return new ViewHolder(itemView);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.text_view_item_quality.setText("تحميل بجودة " + streamModels.get(position).getQuality());
    }

    @Override
    public int getItemCount() {
        return streamModels.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView text_view_item_quality;

        public ViewHolder(View itemView) {
            super(itemView);
            LinearLayout play = itemView.findViewById(R.id.play);
            text_view_item_quality = itemView.findViewById(R.id.text_view_item_quality);
            play.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int position = getAdapterPosition();
            showPopupMenu(v, position);
        }
    }

    private void showPopupMenu(View v, int position) {
        try {
            String url = streamModels.get(position).getWatch();
            Uri uri = Uri.parse(url);

            String title = streamModels.get(position).getTitle();
            String titleSeries = streamModels.get(position).getTitleSeries();
            String downloadTitle;
            if (titleSeries != null && !titleSeries.isEmpty()) {
                downloadTitle = titleSeries + " - " + title;
            } else {
                downloadTitle = title;
            }

            DownloadManager.Request request = new DownloadManager.Request(uri);
            request.setTitle(downloadTitle);
            request.setDescription("بجودة " + streamModels.get(position).getQuality());
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, uri.getLastPathSegment());

            DownloadManager downloadManager = (DownloadManager) v.getContext().getSystemService(Context.DOWNLOAD_SERVICE);
            long downloadId = downloadManager.enqueue(request);

            String poster = streamModels.get(position).getPoster();
            if (poster != null && !poster.isEmpty()) {
                v.getContext().getSharedPreferences("downloads_posters", Context.MODE_PRIVATE)
                        .edit()
                        .putString(String.valueOf(downloadId), poster)
                        .apply();
            }
        } catch (Exception e) {
            Toast.makeText(v.getContext(), "Error initiating download", Toast.LENGTH_SHORT).show();
        }

        if (MainActivityMoviesDetails.bottomSheetDialog != null) {
            MainActivityMoviesDetails.bottomSheetDialog.dismiss();
        }
        if (DialogDownload.bottomSheetDialog1 != null) {
            DialogDownload.bottomSheetDialog1.dismiss();
        }
    }


}
