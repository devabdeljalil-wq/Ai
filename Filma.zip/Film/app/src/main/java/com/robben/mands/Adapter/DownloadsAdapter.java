package com.robben.mands.Adapter;

import android.app.DownloadManager;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.robben.mands.Models.DownloadItem;
import com.robben.mands.R;

import java.util.List;

public class DownloadsAdapter extends RecyclerView.Adapter<DownloadsAdapter.ViewHolder> {

    private final Context context;
    private final List<DownloadItem> items;
    private final OnDownloadItemClickListener listener;

    public interface OnDownloadItemClickListener {
        void onItemClick(DownloadItem item);
        void onDeleteClick(DownloadItem item);
    }

    public DownloadsAdapter(Context context, List<DownloadItem> items, OnDownloadItemClickListener listener) {
        this.context = context;
        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_download, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        DownloadItem item = items.get(position);

        holder.titleView.setText(item.getTitle());
        holder.progressView.setProgress(item.getProgress());
        holder.percentageView.setText(item.getProgress() + "%");

        String statusStr;
        switch (item.getStatus()) {
            case DownloadManager.STATUS_PENDING:
                statusStr = "في الانتظار...";
                break;
            case DownloadManager.STATUS_RUNNING:
                statusStr = "جاري التحميل...";
                break;
            case DownloadManager.STATUS_PAUSED:
                statusStr = "متوقف مؤقتاً";
                break;
            case DownloadManager.STATUS_SUCCESSFUL:
                statusStr = "مكتمل";
                break;
            case DownloadManager.STATUS_FAILED:
                statusStr = "فشل التحميل";
                break;
            default:
                statusStr = "غير معروف";
                break;
        }
        holder.statusView.setText(statusStr);

        // Load poster image using Glide
        if (item.getPosterUrl() != null && !item.getPosterUrl().isEmpty()) {
            Glide.with(context)
                    .load(item.getPosterUrl())
                    .into(holder.posterView);
        } else {
            holder.posterView.setImageResource(R.drawable.shape_item); // Use a basic drawable shape as default
        }

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(item);
            }
        });

        holder.deleteView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onDeleteClick(item);
            }
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView titleView;
        public TextView statusView;
        public TextView percentageView;
        public ProgressBar progressView;
        public ImageView deleteView;
        public ImageView posterView;

        public ViewHolder(View itemView) {
            super(itemView);
            titleView = itemView.findViewById(R.id.download_title);
            statusView = itemView.findViewById(R.id.download_status);
            percentageView = itemView.findViewById(R.id.download_percentage);
            progressView = itemView.findViewById(R.id.download_progress);
            deleteView = itemView.findViewById(R.id.download_delete);
            posterView = itemView.findViewById(R.id.download_poster);
        }
    }
}
