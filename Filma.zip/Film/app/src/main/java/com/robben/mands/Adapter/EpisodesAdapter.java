package com.robben.mands.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.widget.ContentLoadingProgressBar;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.robben.mands.Dialog.DialogDownload;
import com.robben.mands.Dialog.DialogStream;
import com.robben.mands.Models.EpisodesModel;
import com.robben.mands.Models.TimeModel;
import com.robben.mands.R;
import com.robben.mands.Database.TimeDatabase;

import java.util.List;


/**
 * Created by Mezioud on  27,décembre,2021.
 */
public class EpisodesAdapter extends RecyclerView.Adapter<EpisodesAdapter.ViewHolder> {
    Context context;
    List<EpisodesModel> episodesModels;
     String url;


    public EpisodesAdapter(List<EpisodesModel> episodesModels, Context context) {
        this.context = context;
        this.episodesModels = episodesModels;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_episode, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, @SuppressLint("RecyclerView") int position) {

        Glide.with(holder.itemView)
                .load(episodesModels.get(position).getCover())
                .into(holder.poster);

        holder.episode_text.setText(episodesModels.get(position).getTitleEpisode());


        holder.poster.setOnClickListener(view -> {

            DialogStream dialogStream = new DialogStream((Activity) context);
            dialogStream.showDialog(episodesModels.get(position).getTitleSeries(),episodesModels.get(position).getStream(),episodesModels.get(position).getTitleEpisode());

        });
        holder.download.setOnClickListener(view -> {

            DialogDownload dialogDownload = new DialogDownload((Activity) context);
            dialogDownload.showDialog(episodesModels.get(position).getTitleSeries(),episodesModels.get(position).getStream(),episodesModels.get(position).getTitleEpisode(),episodesModels.get(position).getCover());

        });


        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                TimeDatabase timeDatabase = TimeDatabase.getAppDatabase(context);
                TimeModel timeModel = timeDatabase.timeDao().getTime(episodesModels.get(position).getStream());
                if(timeModel!=null){
                    holder.episode_progress.setProgress(Integer.parseInt(timeModel.getTime()));

                }
            }
        });



    }




    @Override
    public int getItemCount() {

        return episodesModels.size();

    }

    public  class ViewHolder extends RecyclerView.ViewHolder {

        public TextView episode_text;
        public ImageView poster;
        public LinearLayout download;
        public  ContentLoadingProgressBar episode_progress;


        public ViewHolder(View itemView) {
            super(itemView);

            poster = itemView.findViewById(R.id.episode_poster);
            episode_text = itemView.findViewById(R.id.episode_text);
            download = itemView.findViewById(R.id.result_episode_progress_downloaded);
            episode_progress = itemView.findViewById(R.id.episode_progress);



        }




    }





}
