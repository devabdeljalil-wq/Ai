package com.robben.mands.Adapter;


import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.robben.mands.Models.AllMoviesModel;
import com.robben.mands.Models.FavoriteModel;
import com.robben.mands.R;
import com.robben.mands.Ui.MainActivityMoviesDetails;
import com.robben.mands.Ui.MainActivitySeriesDetails;
import com.robben.mands.Utils.Helper;
import com.squareup.picasso.Picasso;

import java.util.List;


/**
 * Created by Mezioud on  20,janvier,2021.
 */

public class FavoriteAdapter extends RecyclerView.Adapter<FavoriteAdapter.ViewHolder> {

    Context context;
    List<FavoriteModel> favoriteModels;
    Helper helper;
     int i=0;

    public FavoriteAdapter(Context context ,List<FavoriteModel> favoriteModels) {
        this.context = context;
        this.favoriteModels = favoriteModels;
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_poster_gride, parent, false);

        return new ViewHolder(itemView);
    }

    @SuppressLint("NotifyDataSetChanged")
    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {

        helper = new Helper(context);



            holder.title.setText(favoriteModels.get(position).getTitle());
            holder.date.setText(favoriteModels.get(position).getDate());
            holder.rank.setText(favoriteModels.get(position).getRank());
            Uri uri = Uri.parse(favoriteModels.get(position).getPoster());
            String token = uri.getLastPathSegment();

            Picasso.get()
                    .load(helper.getUrlImage() + "/uploads/" + token)
                    .into(holder.poster);



    }

    @Override
    public int getItemCount() {
        return (null != favoriteModels ? favoriteModels.size() : 0);

    }


    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public TextView title, date, rank;
        public ImageView poster;
        public RelativeLayout layoutPoster;

        public ViewHolder(View itemView) {
            super(itemView);

            layoutPoster = itemView.findViewById(R.id.layoutPoster);
            title = itemView.findViewById(R.id.title);
            date = itemView.findViewById(R.id.date);
            rank = itemView.findViewById(R.id.rating);
            poster = itemView.findViewById(R.id.poster);
            poster.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int position = getAdapterPosition();
            showPopupMenu(v, position);
        }
    }

    private void showPopupMenu(View v, int position) {
        int a=i++;
        if(a==4) {
            helper.putCount("4");
            i=0;
        } else if(a>4) {
            helper.putCount("0");
            i=0;
        }
        if (favoriteModels.get(position).getType().equals("series")) {
            Intent intent = new Intent(v.getContext(), MainActivitySeriesDetails.class);
            intent.putExtra("KEY_VIDEO_TITLE", favoriteModels.get(position).getTitle());
            intent.putExtra("KEY_VIDEO_POSTER", favoriteModels.get(position).getPoster());
            intent.putExtra("KEY_DETAILS_URI", favoriteModels.get(position).getStream());
            intent.putExtra("KEY_DETAILS_DATE", favoriteModels.get(position).getDate());
            intent.putExtra("KEY_DETAILS_RANK", favoriteModels.get(position).getRank());
            intent.putExtra("KEY_DETAILS_QUALITY", favoriteModels.get(position).getQuality());
            intent.putExtra("KEY_DETAILS_TYPE", favoriteModels.get(position).getType());

            v.getContext().startActivity(intent);

        } else if (favoriteModels.get(position).getType().equals("movie")) {
            Intent intent = new Intent(v.getContext(), MainActivityMoviesDetails.class);
            intent.putExtra("KEY_VIDEO_TITLE", favoriteModels.get(position).getTitle());
            intent.putExtra("KEY_VIDEO_POSTER", favoriteModels.get(position).getPoster());
            intent.putExtra("KEY_DETAILS_URI", favoriteModels.get(position).getStream());
            intent.putExtra("KEY_DETAILS_DATE", favoriteModels.get(position).getDate());
            intent.putExtra("KEY_DETAILS_RANK", favoriteModels.get(position).getRank());
            intent.putExtra("KEY_DETAILS_QUALITY", favoriteModels.get(position).getQuality());
            intent.putExtra("KEY_DETAILS_TYPE", favoriteModels.get(position).getType());

            v.getContext().startActivity(intent);


        }


    }

}