package com.robben.mands.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.robben.mands.Models.GenresMovieModel;
import com.robben.mands.R;
import com.robben.mands.Ui.MainActivityShowGenres;

import java.util.List;


/**
 * Created by Mezioud on  26,décembre,2021.
 */
public class GenresSeriesAdapter extends RecyclerView.Adapter<GenresSeriesAdapter.ViewHolder> {

    Context context;
    List<GenresMovieModel> genresMovieModels;


    public GenresSeriesAdapter(List<GenresMovieModel> genresMovieModels, Context context) {
        this.context = context;
        this.genresMovieModels = genresMovieModels;
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_genre, parent, false);

        return new ViewHolder(itemView);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {

        holder.title.setText(genresMovieModels.get(position).getTitle());

    }

    @Override
    public int getItemCount() {

        return genresMovieModels.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public TextView title;
        public ViewHolder(View itemView) {
            super(itemView);

            title = itemView.findViewById(R.id.title);
            title.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int position = getAdapterPosition();
            showPopupMenu(v, position);
        }
    }

    private void showPopupMenu(View v, int position) {


        Intent intent = new Intent(v.getContext(), MainActivityShowGenres.class);
        intent.putExtra("KEY_GENRE_ID", genresMovieModels.get(position).getId());
        intent.putExtra("KEY_GENRE_TITLE", genresMovieModels.get(position).getTitle());
        intent.putExtra("KEY_GENRE_TYPE", "series");

        v.getContext().startActivity(intent);

    }

}
