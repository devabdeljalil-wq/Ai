package com.robben.mands.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.robben.mands.Dialog.DialogStream;
import com.robben.mands.Models.StreamModel;
import com.robben.mands.R;
import com.robben.mands.Ui.MainActivityMoviesDetails;
import com.robben.mands.Ui.MainActivityPlayer;

import java.util.List;


/**
 * Created by Mezioud on  26,décembre,2021.
 */
public class StreamAdapter extends RecyclerView.Adapter<StreamAdapter.ViewHolder> {

    Context context;
     List<StreamModel> streamModels;


    public StreamAdapter(List<StreamModel> streamModels,Context context) {
        this.context = context;
        this.streamModels = streamModels;
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_stream, parent, false);

        return new ViewHolder(itemView);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {

        holder.text_view_item_quality.setText("شاهد بجودة "+streamModels.get(position).getQuality());

    }

    @Override
    public int getItemCount() {
        return streamModels.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public TextView text_view_item_quality;
        public ViewHolder(View itemView) {
            super(itemView);

            LinearLayout play = itemView.findViewById(R.id.play);
            text_view_item_quality = itemView.findViewById(R.id.text_view_item_quality);
            play.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int position = getAdapterPosition();
            showPopupMenu(v, position);
        }
    }

    private void showPopupMenu(View v, int position) {

        if (MainActivityMoviesDetails.bottomSheetDialog!=null){
            MainActivityMoviesDetails.bottomSheetDialog.dismiss();

        }
        if (DialogStream.bottomSheetDialog1!=null){
            DialogStream.bottomSheetDialog1.dismiss();

        }

        Intent intent = new Intent(context, MainActivityPlayer.class);

        intent.putExtra("KEY_VIDEO_ID", streamModels.get(position).getMovieId());
        intent.putExtra("KEY_VIDEO_QUALITY", streamModels.get(position).getQuality());
        intent.putExtra("KEY_VIDEO_URI", streamModels.get(position).getWatch());
        intent.putExtra("KEY_VIDEO_TITLE",streamModels.get(position).getTitle());
        intent.putExtra("KEY_VIDEO_TITLE_SERIES",streamModels.get(position).getTitleSeries());

        v.getContext().startActivity(intent);
        

    }

}
