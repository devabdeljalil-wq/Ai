package com.robben.mands.Database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.robben.mands.Interfaces.FavoriteDao;
import com.robben.mands.Models.FavoriteModel;

/**
 * Created by Mezioud on  01,avril,2022.
 */

@Database(entities = {FavoriteModel.class}, version = 1, exportSchema = false)
public abstract class FavoriteDatabase extends RoomDatabase {
    public abstract FavoriteDao favoriteDao();

    private static FavoriteDatabase INSTANCE;

    public static FavoriteDatabase getAppDatabase(Context context) {
        if (INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(context.getApplicationContext(), FavoriteDatabase.class, "favorite-database").build();
        }
        return INSTANCE;
    }

    public static void destroyInstance() {
        INSTANCE = null;
    }
}