package com.robben.mands.Database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import com.robben.mands.Interfaces.TimeDao;
import com.robben.mands.Models.TimeModel;

/**
 * Created by Mezioud on  01,avril,2022.
 */

@Database(entities = {TimeModel.class}, version = 1, exportSchema = false)
public abstract class TimeDatabase extends RoomDatabase {
    public abstract TimeDao timeDao();

    private static TimeDatabase INSTANCE;

    public static TimeDatabase getAppDatabase(Context context) {
        if (INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(context.getApplicationContext(), TimeDatabase.class, "time-database").build();
        }
        return INSTANCE;
    }

    public static void destroyInstance() {
        INSTANCE = null;
    }
}