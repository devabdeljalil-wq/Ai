package com.robben.mands.Dialog;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.net.Uri;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.robben.mands.Adapter.StreamAdapter;
import com.robben.mands.Models.StreamModel;
import com.robben.mands.R;
import com.robben.mands.Utils.Helper;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DialogStream {
    Activity activity;
    List<StreamModel> streamModels = new ArrayList<>();
    StreamAdapter streamAdapter;
    RecyclerView mRecyclerView;
    String link,titleEpisode,titleSeries;
    LinearLayout wait;
    public static BottomSheetDialog bottomSheetDialog1;
     Helper helper;

    public DialogStream(Activity activity) {
        this.activity = activity;
    }

    public void showDialog(String titleSeries, String message, String title) {
        link = message;
        this.titleEpisode =title;
        this.titleSeries =titleSeries;
        bottomSheetDialog1 = new BottomSheetDialog(
               activity, R.style.BottomSheetDialogTheme);

        @SuppressLint("InflateParams") View bottomSheetView = LayoutInflater.from(activity)
                .inflate(R.layout.bottom_stream, null);
         wait = bottomSheetView.findViewById(R.id.wait);
         mRecyclerView = bottomSheetView.findViewById(R.id.recyclerview);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false));
        streamAdapter = new StreamAdapter(streamModels, activity);
        mRecyclerView.setAdapter(streamAdapter);
        bottomSheetDialog1.setContentView(bottomSheetView);
        bottomSheetDialog1.show();
        helper =new Helper(activity);

        Content1080p content = new Content1080p();
        content.execute();
    }

    @SuppressLint("StaticFieldLeak")
    private class Content1080p extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            try {
                Document doc = Jsoup.connect(link)
                        .timeout(30000)
                        .userAgent("Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:25.0) Gecko/20100101 Firefox/25.0")
                        .referrer("http://www.google.com")
                        .get();
                Elements elementsLink1 = doc.getElementsByClass("tab-content quality");
                String linkGetLinkWatch = elementsLink1.select("a").attr("href");

                Uri go1 = Uri.parse(linkGetLinkWatch);
                String goId1 = go1.getLastPathSegment();
                Pattern pattern = Pattern.compile("(\\d+)");
                Matcher m = pattern.matcher(link);

                if (m.find()) {
                    String movieId = m.group();
                    String url = helper.getUrlDefault()+"/watch/" + goId1 + "/" + movieId;

                    Document doc1 = Jsoup.connect(url)
                            .userAgent("Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:25.0) Gecko/20100101 Firefox/25.0")
                            .get();
                    Elements elementsLink = doc1.select("source");

                    int sizeSource = elementsLink.size();

                    for (int i = 0; i < sizeSource; i++) {

                        String quality = elementsLink.eq(i).attr("size");
                        String watch = elementsLink.eq(i).attr("src");

                        streamModels.add(new StreamModel(link,titleSeries,titleEpisode, quality, watch));
                    }

                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @SuppressLint("NotifyDataSetChanged")
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            wait.setVisibility(View.GONE);
            mRecyclerView.setVisibility(View.VISIBLE);
            streamAdapter.notifyDataSetChanged();
        }
    }

}