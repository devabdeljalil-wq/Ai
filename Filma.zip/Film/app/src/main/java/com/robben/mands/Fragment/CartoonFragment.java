package com.robben.mands.Fragment;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.robben.mands.Adapter.AllMoviesAdapter;
import com.robben.mands.Models.AllMoviesModel;
import com.robben.mands.Models.GenresMovieModel;
import com.robben.mands.R;
import com.robben.mands.Utils.Helper;
import com.robben.mands.Utils.Utility;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class CartoonFragment extends Fragment  {


     String htmlData;

    public static CartoonFragment newInstance() {

        return new CartoonFragment();
    }
    RecyclerView mRecyclerView;
    AllMoviesAdapter adapter0;
    ProgressBar progress0 ;

    int page = 1;
    int mNoOfColumns;
    List<AllMoviesModel> allMoviesModels0 = new ArrayList<>();
    List<GenresMovieModel> genresMovieModels = new ArrayList<>();
    LinearLayout layout1,wait,btnGenre;
    Helper helper;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_cartoon, container, false);

        helper = new Helper(getActivity());

        mNoOfColumns = Utility.calculateNoOfColumns(getActivity());

        wait = v.findViewById(R.id.wait);
        layout1 = v.findViewById(R.id.layout1);
        btnGenre = v.findViewById(R.id.btnGenre);

        mRecyclerView = v.findViewById(R.id.home_expanded_recycler);
        progress0 = v.findViewById(R.id.progress_circular0);

        GridLayoutManager mGridLayoutManager = new GridLayoutManager(getActivity(), mNoOfColumns);
        mRecyclerView.setLayoutManager(mGridLayoutManager);

        adapter0 = new AllMoviesAdapter(allMoviesModels0, getActivity());
        mRecyclerView.setAdapter(adapter0);

        Content content = new Content();
        content.execute();

        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);

                if (!recyclerView.canScrollVertically(1) && newState==RecyclerView.SCROLL_STATE_IDLE) {
                    progress0.setVisibility(View.VISIBLE);

                    Content content = new Content();
                    content.execute();

                }
            }
        });


        return v;

    }



    @SuppressLint("StaticFieldLeak")
    private class Content extends AsyncTask<Void,Void,Void> {

        @Override
        protected Void doInBackground(Void... voids) {

            URL google = null;
            try {
                String url = helper.getUrlDefault()+"/series?category=30&page="+page++;

                google = new URL(url);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            BufferedReader in = null;
            try {
                assert google != null;
                in = new BufferedReader(new InputStreamReader(google.openStream()));
            } catch (IOException e) {
                e.printStackTrace();
            }
            String input = null;
            StringBuilder stringBuffer = new StringBuilder();
            while (true)
            {
                try {
                    assert in != null;
                    if ((input = in.readLine()) == null) break;
                } catch (IOException e) {
                    e.printStackTrace();
                }
                stringBuffer.append(input);
            }
            try {
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            htmlData = stringBuffer.toString();
            Document doc = Jsoup.parse(htmlData);

            Elements data = doc.getElementsByClass("col-lg-auto col-md-4 col-6 mb-12");
            Elements ElementDate = doc.getElementsByClass("badge badge-pill badge-secondary ml-1");
            Elements ElementRank = doc.getElementsByClass("label rating");
            Elements ElementQuality = doc.getElementsByClass("label quality");
            Elements ElementType = doc.getElementsByClass("icn add-to-fav mr-4 private hide");

            int size = data.size();
            for (int i = 0; i < size; i++) {

                String title =  data.select("div.entry-image")
                        .select("div.entry-image img")
                        .eq(i)
                        .attr("alt");
                String poster = data.select("div.entry-image")
                        .select("div.entry-image img")
                        .eq(i)
                        .attr("data-src");
                String stream = data.select("div.entry-image")
                        .select("a")
                        .eq(i)
                        .attr("href");

                String type = ElementType
                        .select("a")
                        .eq(i)
                        .attr("data-type");
                String date = ElementDate.eq(i)
                        .text();
                String rank = ElementRank.eq(i)
                        .text();
                String quality = ElementQuality.eq(i)
                        .text();
                allMoviesModels0.add(new AllMoviesModel(title,type,date,rank,quality, poster, stream,"0"));

            }

            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @SuppressLint("NotifyDataSetChanged")
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            progress0.setVisibility(View.GONE);
            adapter0.notifyDataSetChanged();
            wait.setVisibility(View.GONE);
            layout1.setVisibility(View.VISIBLE);
        }
    }

}