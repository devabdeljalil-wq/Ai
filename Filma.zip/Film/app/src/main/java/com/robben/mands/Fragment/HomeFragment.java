package com.robben.mands.Fragment;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.robben.mands.Adapter.HorAllMoviesAdapter;

import com.robben.mands.Models.AllMoviesModel;
import com.robben.mands.R;
import com.robben.mands.Ui.MainActivityMoviesDetails;
import com.robben.mands.Ui.MainActivitySeriesDetails;
import com.robben.mands.Utils.Helper;
import com.robben.mands.Utils.Utility;
import com.squareup.picasso.Picasso;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {


    String titleBanner0,titleBanner1, titleBanner2, posterBanner0,posterBanner1, posterBanner2, coverBanner0,coverBanner1, coverBanner2, plotBanner0,plotBanner1, plotBanner2,rankBanner0, rankBanner1, rankBanner2,streamBanner0,streamBanner1, streamBanner2;
     int sizeData;
     int sizeMovies;
     int sizeData1;

    public static HomeFragment newInstance() {
        return new HomeFragment();
    }

    TextView titleMovie0, rankMovie0, plotMovie0,titleMovie1, rankMovie1, plotMovie1, titleMovie2, rankMovie2, plotMovie2;
    ImageView coverMovie0,posterMovie1, coverMovie1, posterMovie2, coverMovie2;
    RelativeLayout layout1;
    LinearLayout wait,banner0;
    Button more0, more1;
    RecyclerView recyclerview1, recyclerview2,recyclerview3;
    List<AllMoviesModel> allMoviesModels1 = new ArrayList<>();
    List<AllMoviesModel> allMoviesModels2 = new ArrayList<>();
    List<AllMoviesModel> allMoviesModels3 = new ArrayList<>();
    HorAllMoviesAdapter adapter1, adapter2, adapter3;
    LinearLayoutManager layoutManager1, layoutManager2, layoutManager3;
    int mNoOfColumns;
    Helper helper;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_home, container, false);
        mNoOfColumns = Utility.calculateNoOfColumns(getActivity());

        helper =new Helper(getActivity());

        layoutManager1 = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        layoutManager2 = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        layoutManager3 = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);

        recyclerview1 = v.findViewById(R.id.recyclerview1);
        recyclerview2 = v.findViewById(R.id.recyclerview2);
        recyclerview3 = v.findViewById(R.id.recyclerview3);

        titleMovie0 = v.findViewById(R.id.titleMovie0);
        coverMovie0 = v.findViewById(R.id.coverMovie0);
        plotMovie0 = v.findViewById(R.id.plotMovie0);
        rankMovie0 = v.findViewById(R.id.rankMovie0);

        titleMovie1 = v.findViewById(R.id.titleMovie1);
        posterMovie1 = v.findViewById(R.id.posterMovie1);
        coverMovie1 = v.findViewById(R.id.coverMovie1);
        plotMovie1 = v.findViewById(R.id.plotMovie1);
        rankMovie1 = v.findViewById(R.id.rankMovie1);

        titleMovie2 = v.findViewById(R.id.titleMovie2);
        posterMovie2 = v.findViewById(R.id.posterMovie2);
        coverMovie2 = v.findViewById(R.id.coverMovie2);
        plotMovie2 = v.findViewById(R.id.plotMovie2);
        rankMovie2 = v.findViewById(R.id.rankMovie2);


        wait = v.findViewById(R.id.wait);
        banner0 = v.findViewById(R.id.banner0);
        layout1 = v.findViewById(R.id.layout1);


        coverMovie0.setOnClickListener(view -> {


            if(streamBanner0.contains("movie"))
            {
                Intent intent = new Intent(getActivity(), MainActivityMoviesDetails.class);
                intent.putExtra("KEY_MOVIE_NAME", streamBanner0);
                intent.putExtra("KEY_VIDEO_TITLE", titleBanner0);
                intent.putExtra("KEY_VIDEO_POSTER", posterBanner0);
                intent.putExtra("KEY_DETAILS_URI", streamBanner0);
                intent.putExtra("KEY_DETAILS_DATE", "2021");
                intent.putExtra("KEY_DETAILS_RANK", rankBanner0);
                intent.putExtra("KEY_DETAILS_TYPE", "movie");
                intent.putExtra("KEY_DETAILS_QUALITY", "");
                startActivity(intent);
            }else {

                Intent intent = new Intent(getActivity(), MainActivitySeriesDetails.class);
                intent.putExtra("KEY_MOVIE_NAME", streamBanner0);
                intent.putExtra("KEY_VIDEO_TITLE", titleBanner0);
                intent.putExtra("KEY_VIDEO_POSTER", posterBanner0);
                intent.putExtra("KEY_DETAILS_URI", streamBanner0);
                intent.putExtra("KEY_DETAILS_DATE", "2022");
                intent.putExtra("KEY_DETAILS_RANK", rankBanner0);
                intent.putExtra("KEY_DETAILS_TYPE", "series");
                intent.putExtra("KEY_DETAILS_QUALITY", "");
                startActivity(intent);
            }

        });

        coverMovie1.setOnClickListener(view -> {
            Intent intent = new Intent(getActivity(), MainActivityMoviesDetails.class);
            intent.putExtra("KEY_MOVIE_NAME", streamBanner1);
            intent.putExtra("KEY_VIDEO_TITLE", titleBanner1);
            intent.putExtra("KEY_VIDEO_POSTER", posterBanner1);
            intent.putExtra("KEY_DETAILS_URI", streamBanner1);
            intent.putExtra("KEY_DETAILS_DATE", "2022");
            intent.putExtra("KEY_DETAILS_RANK", rankBanner0);
            intent.putExtra("KEY_DETAILS_TYPE", "movie");
            intent.putExtra("KEY_DETAILS_QUALITY", "");
            startActivity(intent);
        });
        coverMovie2.setOnClickListener(view -> {
            Intent intent = new Intent(getActivity(), MainActivitySeriesDetails.class);
            intent.putExtra("KEY_MOVIE_NAME", streamBanner2);
            intent.putExtra("KEY_VIDEO_TITLE", titleBanner2);
            intent.putExtra("KEY_VIDEO_POSTER", posterBanner2);
            intent.putExtra("KEY_DETAILS_URI", streamBanner2);
            intent.putExtra("KEY_DETAILS_DATE", "2022");
            intent.putExtra("KEY_DETAILS_RANK", "");
            intent.putExtra("KEY_DETAILS_TYPE", "series");
            intent.putExtra("KEY_DETAILS_QUALITY", "");
            startActivity(intent);
        });

        Layout1();
        Layout2();
        Layout3();




        Content content = new Content();
        content.execute();




        return v;
    }


    private void Layout1() {

        recyclerview1.setLayoutManager(layoutManager1);
        adapter1 = new HorAllMoviesAdapter(allMoviesModels1, getActivity());
        recyclerview1.setAdapter(adapter1);
    }

    private void Layout2() {

        recyclerview2.setLayoutManager(layoutManager2);
        adapter2 = new HorAllMoviesAdapter(allMoviesModels2, getActivity());
        recyclerview2.setAdapter(adapter2);
    }

    private void Layout3() {

        recyclerview3.setLayoutManager(layoutManager3);
        adapter3 = new HorAllMoviesAdapter(allMoviesModels3, getActivity());
        recyclerview3.setAdapter(adapter3);
    }


    @SuppressLint("StaticFieldLeak")
    private class Content extends AsyncTask<Void, Void, Void> {


        @Override
        protected Void doInBackground(Void... voids) {

            URL google = null;
            try {
                String url = helper.getUrlDefault() + "/one1";

                google = new URL(url);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            BufferedReader in = null;
            try {
                assert google != null;
                in = new BufferedReader(new InputStreamReader(google.openStream()));
            } catch (IOException e) {
                e.printStackTrace();
            }
            String input = null;
            StringBuilder stringBuffer = new StringBuilder();
            while (true)
            {
                try {
                    assert in != null;
                    if ((input = in.readLine()) == null) break;
                } catch (IOException e) {
                    e.printStackTrace();
                }
                stringBuffer.append(input);
            }
            try {
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            String htmlData = stringBuffer.toString();

            Document docOne = Jsoup.parse(htmlData);



            Elements data0 = docOne.getElementsByClass("widget-1 widget mb-4 mb-lg-0");
             titleBanner0= data0.select("h3[class=entry-title font-size-38 font-size-md-50 font-weight-bold]").text();
             coverBanner0 = data0.attr("style").replace("background-image: url('", "").replace("')", "");
             streamBanner0 = data0.select("h3[class=entry-title font-size-38 font-size-md-50 font-weight-bold]").select("a").attr("href");
             rankBanner0 =  data0.select("span[class=label rating ml-2]").text();
             plotBanner0 =data0.select("p[class=text text-white font-size-18 mb-3]").text();



            Elements data1 = docOne.getElementsByClass("swiper-slide");

            int sizeData1 = data1.size();
            for (int i = 0; i < sizeData1; i++) {


                String titleMovies =
                        data1.select("h3[class=entry-title font-size-14 m-0]")
                                .eq(i)
                                .text();
                String posterMovies = data1.select("div[class=entry-image]")
                        .select("img")
                        .eq(i)
                        .attr("src");
                String streamMovies = data1.select("div[class=entry-image]")
                        .select("a")
                        .eq(i)
                        .attr("href");
                String typeMovies = data1.select("a[class=icn add-to-fav mr-4 private hide]")
                        .eq(i)
                        .attr("data-type");

                String dateMovies = data1.select("span[class=badge badge-pill badge-secondary ml-1]")
                        .eq(i)
                        .text();

                String rankMovies =  data1.select("span[class=label rating]")
                        .eq(i)
                        .text();
                String qualityMovies = data1.select("span[class=label quality]")
                        .eq(i)
                        .text();
                if (typeMovies.equals("movie")||typeMovies.equals("series")) {
                    allMoviesModels1.add(new AllMoviesModel(titleMovies, typeMovies, dateMovies, rankMovies, qualityMovies, posterMovies, streamMovies, "0"));
                }

            }


            Elements data2 = docOne.getElementsByClass("col-6 col-lg-2 col-md-4 mb-12");

            int sizeData2 = data2.size();
            for (int i = 0; i < sizeData2; i++) {

                String titleMovies = data2.select("div.entry-image")
                        .select("div.entry-image img")
                        .eq(i)
                        .attr("alt");

                String posterMovies = data2.select("div.entry-image")
                        .select("div.entry-image img")
                        .eq(i)
                        .attr("data-src");

                String streamMovies = data2.select("div.entry-image")
                        .select("a")
                        .eq(i)
                        .attr("href");
                String typeMovies = data2.select("a[class=icn add-to-fav mr-4 private hide]")
                        .eq(i)
                        .attr("data-type");

                String dateMovies = data2.select("span[class=badge badge-pill badge-secondary ml-1]")
                        .eq(i)
                        .text();

                String rankMovies =  data2.select("span[class=label rating]")
                        .eq(i)
                        .text();
                String qualityMovies = data2.select("span[class=label quality]")
                        .eq(i)
                        .text();
                allMoviesModels2.add(new AllMoviesModel(titleMovies, typeMovies, dateMovies, rankMovies, qualityMovies, posterMovies, streamMovies, "0"));


                }

            Elements data3 = docOne.getElementsByClass("col-lg col-md-4 col-6 mb-12");

            int sizeData3 = data2.size();
            for (int i = 0; i < sizeData3; i++) {


                String titleMovies =
                        data3.select("div[class=entry-image]")
                        .select("img")
                        .eq(i)
                        .attr("alt");
                String posterMovies = data3.select("div[class=entry-image]")
                        .select("img")
                        .eq(i)
                        .attr("data-src");
                String streamMovies = data3.select("div[class=entry-image]")
                        .select("a")
                        .eq(i)
                        .attr("href");
                String typeMovies = data3.select("a[class=icn add-to-fav mr-4 private hide]")
                        .eq(i)
                        .attr("data-type");

                String dateMovies = data3.select("span[class=badge badge-pill badge-secondary ml-1]")
                        .eq(i)
                        .text();

                String rankMovies =  data3.select("span[class=label rating]")
                        .eq(i)
                        .text();
                String qualityMovies = data3.select("span[class=label quality]")
                        .eq(i)
                        .text();
                allMoviesModels3.add(new AllMoviesModel(titleMovies, typeMovies, dateMovies, rankMovies, qualityMovies, posterMovies, streamMovies, "0"));


            }


            Elements dataBanner = docOne.getElementsByClass("entry-box entry-box-2 d-flex flex-wrap no-gutters p-4 p-lg-5 mb-12");
            Elements ElementTitleBanner = docOne.getElementsByClass("entry-poster text-center mb-4 mb-md-0");
            Elements ElementPlotBanner = docOne.getElementsByClass("entry-desc font-size-16 text-white mb-0 mt-3");
            Elements ElementRankBanner = docOne.getElementsByClass("entry-body text-center text-md-right");
            Elements ElementCoverBanner = docOne.getElementsByClass("entry-box entry-box-2 d-flex flex-wrap no-gutters p-4 p-lg-5 mb-12");


            int sizeBanner = dataBanner.size();
            for (int i = 0; i < sizeBanner; i++) {

                titleBanner1 = ElementTitleBanner.select("img").eq(0).attr("alt");
                posterBanner1 = ElementTitleBanner.select("img").eq(0).attr("data-src");
                coverBanner1 = ElementCoverBanner.eq(0).attr("style").replace("background-image: url('", "").replace("')", "");
                streamBanner1 = ElementTitleBanner.select("a").eq(0).attr("href");
                rankBanner1 = dataBanner.select("span[class=label rating]").eq(0).text();
                plotBanner1 = ElementPlotBanner.eq(0).text();

                titleBanner2 = ElementTitleBanner.select("img").eq(1).attr("alt");
                posterBanner2 = ElementTitleBanner.select("img").eq(1).attr("data-src");
                coverBanner2 = ElementCoverBanner.eq(1).attr("style").replace("background-image: url('", "").replace("')", "");
                streamBanner2 = ElementTitleBanner.select("a").eq(1).attr("href");
                rankBanner2 = dataBanner.select("span[class=label rating]").eq(1).text();
                plotBanner2 = ElementPlotBanner.eq(1).text();

            }


            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @SuppressLint("NotifyDataSetChanged")
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);


            if (!coverBanner0.isEmpty()){
                banner0.setVisibility(View.VISIBLE);
                Picasso.get().load(coverBanner0).into(coverMovie0);
                titleMovie0.setText(titleBanner0);
                plotMovie0.setText(plotBanner0);
                rankMovie0.setText(rankBanner0);
            }

            titleMovie1.setText(titleBanner1);
            plotMovie1.setText(plotBanner1);
            rankMovie1.setText(rankBanner1);
            Picasso.get().load(posterBanner1).into(posterMovie1);
            Picasso.get().load(coverBanner1).into(coverMovie1);

            titleMovie2.setText(titleBanner2);
            plotMovie2.setText(plotBanner2);
            rankMovie2.setText(rankBanner2);
            Picasso.get().load(posterBanner2).into(posterMovie2);
            Picasso.get().load(coverBanner2).into(coverMovie2);

            adapter1.notifyDataSetChanged();
            adapter2.notifyDataSetChanged();
            adapter3.notifyDataSetChanged();

            wait.setVisibility(View.GONE);
            layout1.setVisibility(View.VISIBLE);

        }
    }

}