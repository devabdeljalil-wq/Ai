package com.robben.mands.Fragment;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.robben.mands.Adapter.AllMoviesAdapter;
import com.robben.mands.Adapter.GenresSeriesAdapter;
import com.robben.mands.Adapter.SectionSeriesAdapter;
import com.robben.mands.Models.AllMoviesModel;
import com.robben.mands.Models.GenresMovieModel;
import com.robben.mands.R;
import com.robben.mands.Utils.Helper;
import com.robben.mands.Utils.Utility;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;


public class SeriesFragment extends Fragment {

    public static SeriesFragment newInstance() {

        return new SeriesFragment();
    }
    RecyclerView mRecyclerView;
    AllMoviesAdapter adapter0;
    ProgressBar progress0 ;

    int page = 1;
    int mNoOfColumns;
    List<AllMoviesModel> allMoviesModels0 = new ArrayList<>();
    List<GenresMovieModel> genresMovieModels = new ArrayList<>();
    LinearLayout layout1,wait,btnGenre;
    Helper helper;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_series, container, false);
        mNoOfColumns = Utility.calculateNoOfColumns(getActivity());
        helper = new Helper(getActivity());


        wait = v.findViewById(R.id.wait);
        layout1 = v.findViewById(R.id.layout1);

        mRecyclerView = v.findViewById(R.id.home_expanded_recycler);
        progress0 = v.findViewById(R.id.progress_circular0);

        GridLayoutManager mGridLayoutManager = new GridLayoutManager(getActivity(), mNoOfColumns);
        mRecyclerView.setLayoutManager(mGridLayoutManager);

        adapter0 = new AllMoviesAdapter(allMoviesModels0, getActivity());
        mRecyclerView.setAdapter(adapter0);

        btnGenre = v.findViewById(R.id.btnGenre);

        Content content = new Content();
        content.execute();
        btnGenre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showGenre();
            }
        });

        LinearLayout btnSections = v.findViewById(R.id.btnSections);

        btnSections.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showSections();
            }
        });

        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);

                if (!recyclerView.canScrollVertically(1) && newState==RecyclerView.SCROLL_STATE_IDLE) {
                    progress0.setVisibility(View.VISIBLE);

                    Content content = new Content();
                    content.execute();

                }
            }
        });

        return v;
    }
    private void showGenre() {

        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(
                getActivity(), R.style.BottomSheetDialogTheme
        );
        genresMovieModels.clear();


        @SuppressLint("InflateParams") View bottomSheetView = LayoutInflater.from(getActivity())
                .inflate(R.layout.bottom_genres,null);
        mRecyclerView = bottomSheetView.findViewById(R.id.home_expanded_recycler);
        final Button more0 = bottomSheetView.findViewById(R.id.more0);
        progress0 = bottomSheetView.findViewById(R.id.progress_circular0);
        TextView txt1 = bottomSheetView.findViewById(R.id.txt1);
        TextView txt2 = bottomSheetView.findViewById(R.id.txt2);
        txt1.setText("قائمة الاصناف");
        txt2.setText("اختر الصنف الذي يعجبك");

        GridLayoutManager mGridLayoutManager = new GridLayoutManager(getActivity(), mNoOfColumns);
        mRecyclerView.setLayoutManager(mGridLayoutManager);

        GenresSeriesAdapter adapter1 = new GenresSeriesAdapter(genresMovieModels, getActivity());
        mRecyclerView.setAdapter(adapter1);
        try {
            JSONObject obj = new JSONObject(loadJSONFromAsset());
            JSONArray genreArray = obj.getJSONArray("list");

            for (int i = 0; i < genreArray.length(); i++) {
                JSONObject genreObject = genreArray.getJSONObject(i);
                String id = genreObject.getString("id");
                String title = genreObject.getString("title");

                genresMovieModels.add(new GenresMovieModel(id,title));

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        more0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetDialog.cancel();

            }
        });



        bottomSheetDialog.setContentView(bottomSheetView);
        bottomSheetDialog.show();


    }
    public String loadJSONFromAsset() {
        String json;
        try {
            InputStream is = getActivity().getAssets().open("genres.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, StandardCharsets.UTF_8);
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }
    private void showSections() {

        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(
                getActivity(), R.style.BottomSheetDialogTheme
        );
        genresMovieModels.clear();


        @SuppressLint("InflateParams") View bottomSheetView = LayoutInflater.from(getActivity())
                .inflate(R.layout.bottom_genres,null);
        mRecyclerView = bottomSheetView.findViewById(R.id.home_expanded_recycler);
        final Button more0 = bottomSheetView.findViewById(R.id.more0);
        progress0 = bottomSheetView.findViewById(R.id.progress_circular0);
        TextView txt1 = bottomSheetView.findViewById(R.id.txt1);
        TextView txt2 = bottomSheetView.findViewById(R.id.txt2);
        txt1.setText("قائمة الاقسام");
        txt2.setText("اختر القسم الذي يعجبك");

        GridLayoutManager mGridLayoutManager = new GridLayoutManager(getActivity(), mNoOfColumns);
        mRecyclerView.setLayoutManager(mGridLayoutManager);

        SectionSeriesAdapter sectionSeriesAdapter = new SectionSeriesAdapter(genresMovieModels, getActivity());
        mRecyclerView.setAdapter(sectionSeriesAdapter);
        try {
            JSONObject obj = new JSONObject(loadSections());
            JSONArray genreArray = obj.getJSONArray("list");

            for (int i = 0; i < genreArray.length(); i++) {
                JSONObject genreObject = genreArray.getJSONObject(i);
                String id = genreObject.getString("id");
                String title = genreObject.getString("title");

                genresMovieModels.add(new GenresMovieModel(id,title));

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        more0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetDialog.cancel();

            }
        });



        bottomSheetDialog.setContentView(bottomSheetView);
        bottomSheetDialog.show();


    }
    public String loadSections() {
        String json;
        try {
            InputStream is = getActivity().getAssets().open("sections.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, StandardCharsets.UTF_8);
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }


    @SuppressLint("StaticFieldLeak")
    private class Content extends AsyncTask<Void,Void,Void> {

        @Override
        protected Void doInBackground(Void... voids) {

            String url = helper.getUrlDefault()+"/series?page="+page++;
            URL google = null;
            try {
                google = new URL(url);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            BufferedReader in = null;
            try {
                assert google != null;
                in = new BufferedReader(new InputStreamReader(google.openStream()));
            } catch (IOException e) {
                e.printStackTrace();
            }
            String input = null;
            StringBuilder stringBuffer = new StringBuilder();
            while (true)
            {
                try {
                    assert in != null;
                    if ((input = in.readLine()) == null) break;
                } catch (IOException e) {
                    e.printStackTrace();
                }
                stringBuffer.append(input);
            }
            try {
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            String htmlData = stringBuffer.toString();
            Document doc = Jsoup.parse(htmlData);

            Elements data = doc.getElementsByClass("col-lg-auto col-md-4 col-6 mb-12");
            Elements ElementDate = doc.getElementsByClass("badge badge-pill badge-secondary ml-1");
            Elements ElementRank = doc.getElementsByClass("label rating");
            Elements ElementQuality = doc.getElementsByClass("label quality");
            Elements ElementType = doc.getElementsByClass("icn add-to-fav mr-4 private hide");

            int size = data.size();
            for (int i = 0; i < size; i++) {

                String title =  data.select("div.entry-image")
                        .select("div.entry-image img")
                        .eq(i)
                        .attr("alt");
                String poster = data.select("div.entry-image")
                        .select("div.entry-image img")
                        .eq(i)
                        .attr("data-src");
                String stream = data.select("div.entry-image")
                        .select("a")
                        .eq(i)
                        .attr("href");

                String type = ElementType
                        .select("a")
                        .eq(i)
                        .attr("data-type");
                String date = ElementDate.eq(i)
                        .text();
                String rank = ElementRank.eq(i)
                        .text();
                String quality = ElementQuality.eq(i)
                        .text();
                allMoviesModels0.add(new AllMoviesModel(title,type,date,rank,quality, poster, stream,"0"));

            }

            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @SuppressLint("NotifyDataSetChanged")
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

                progress0.setVisibility(View.GONE);
                adapter0.notifyDataSetChanged();
                wait.setVisibility(View.GONE);
                layout1.setVisibility(View.VISIBLE);


        }
    }

}