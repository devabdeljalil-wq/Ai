package com.robben.mands.Interfaces;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import com.robben.mands.Models.FavoriteModel;
import java.util.List;

/**
 * Created by Mezioud on  01,avril,2022.
 */


@Dao
public interface FavoriteDao {
    @Insert
    Long insert(FavoriteModel favoriteModel);

    @Query("SELECT * FROM `FavoriteModel` ORDER BY `id` DESC")
    List<FavoriteModel> getFavorite();

    @Query("SELECT * FROM `FavoriteModel` WHERE `stream` =:stream")
    int checkFavorite(String stream);

    @Update
    void update(FavoriteModel favoriteModel);

    @Delete
    void delete(FavoriteModel favoriteModel);

    @Query("DELETE FROM FavoriteModel WHERE stream = :stream")
    abstract void deleteFavorite(String stream);
}