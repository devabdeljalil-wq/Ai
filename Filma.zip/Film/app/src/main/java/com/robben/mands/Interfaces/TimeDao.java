package com.robben.mands.Interfaces;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.robben.mands.Models.TimeModel;

/**
 * Created by Mezioud on  01,avril,2022.
 */


@Dao
public interface TimeDao {
    @Insert
    Long insert(TimeModel timeModel);

    @Query("SELECT * FROM `TimeModel`  WHERE `stream` =:stream")
    TimeModel getTime(String stream);

    @Query("SELECT * FROM `TimeModel` WHERE `stream` =:stream")
    int checkTime(String stream);


    @Query("UPDATE TimeModel SET time=:time WHERE `stream` =:stream")
    void updateTime(String time, String stream);
}