package com.robben.mands.Models;

/**
 * Created by Mezioud on  06,mars,2021.
 */
public class AllMoviesModel {


    String title;
    String type;
    String date;
    String rank;
    String quality;
    String poster;
    String stream;
    String favorite;

    public AllMoviesModel(String title, String type, String date, String rank, String quality, String poster, String stream, String favorite) {
        this.title = title;
        this.type = type;
        this.date = date;
        this.rank = rank;
        this.quality = quality;
        this.poster = poster;
        this.stream = stream;
        this.favorite = favorite;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getQuality() {
        return quality;
    }

    public void setQuality(String quality) {
        this.quality = quality;
    }

    public String getPoster() {
        return poster;
    }

    public void setPoster(String poster) {
        this.poster = poster;
    }

    public String getStream() {
        return stream;
    }

    public void setStream(String stream) {
        this.stream = stream;
    }

    public String getFavorite() {
        return favorite;
    }

    public void setFavorite(String favorite) {
        this.favorite = favorite;
    }
}