package com.robben.mands.Models;

/**
 * Created by Mezioud on  23,août,2021.
 */
public class CastsModel {

    String original_name;
    String profile_path;
    String details_path;

    public CastsModel(String original_name, String profile_path, String details_path) {
        this.original_name = original_name;
        this.profile_path = profile_path;
        this.details_path = details_path;
    }

    public String getOriginal_name() {
        return original_name;
    }

    public void setOriginal_name(String original_name) {
        this.original_name = original_name;
    }

    public String getProfile_path() {
        return profile_path;
    }

    public void setProfile_path(String profile_path) {
        this.profile_path = profile_path;
    }

    public String getDetails_path() {
        return details_path;
    }

    public void setDetails_path(String details_path) {
        this.details_path = details_path;
    }
}
