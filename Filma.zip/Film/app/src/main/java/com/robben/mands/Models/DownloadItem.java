package com.robben.mands.Models;

public class DownloadItem {
    private long id;
    private String title;
    private int status;
    private int progress;
    private String localUri;
    private String posterUrl;

    public DownloadItem(long id, String title, int status, int progress, String localUri, String posterUrl) {
        this.id = id;
        this.title = title;
        this.status = status;
        this.progress = progress;
        this.localUri = localUri;
        this.posterUrl = posterUrl;
    }

    public long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public int getStatus() {
        return status;
    }

    public int getProgress() {
        return progress;
    }

    public String getLocalUri() {
        return localUri;
    }

    public String getPosterUrl() {
        return posterUrl;
    }
}
