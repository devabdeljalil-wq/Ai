package com.robben.mands.Models;

/**
 * Created by Mezioud on  27,décembre,2021.
 */
public class EpisodesModel {

    String titleSeries;
    String titleEpisode;
    String cover;
    String stream;


    public EpisodesModel(String titleSeries, String titleEpisode, String cover, String stream) {
        this.titleSeries = titleSeries;
        this.titleEpisode = titleEpisode;
        this.cover = cover;
        this.stream = stream;
    }

    public String getTitleSeries() {
        return titleSeries;
    }

    public void setTitleSeries(String titleSeries) {
        this.titleSeries = titleSeries;
    }

    public String getTitleEpisode() {
        return titleEpisode;
    }

    public void setTitleEpisode(String titleEpisode) {
        this.titleEpisode = titleEpisode;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public String getStream() {
        return stream;
    }

    public void setStream(String stream) {
        this.stream = stream;
    }
}
