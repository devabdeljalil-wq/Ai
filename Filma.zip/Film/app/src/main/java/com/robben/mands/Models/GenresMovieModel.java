package com.robben.mands.Models;

/**
 * Created by Mezioud on  06,janvier,2022.
 */
public class GenresMovieModel {
    String id;
    String title;

    public GenresMovieModel(String id, String title) {
        this.id = id;
        this.title = title;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
