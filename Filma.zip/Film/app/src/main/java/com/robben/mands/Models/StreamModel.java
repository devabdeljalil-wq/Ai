package com.robben.mands.Models;

/**
 * Created by Mezioud on  26,décembre,2021.
 */
public class StreamModel {

    String movieId;
    String titleSeries;
    String title;
    String quality;
    String watch;
    String poster;

    public StreamModel(String movieId, String titleSeries, String title, String quality, String watch) {
        this.movieId = movieId;
        this.titleSeries = titleSeries;
        this.title = title;
        this.quality = quality;
        this.watch = watch;
        this.poster = "";
    }

    public StreamModel(String movieId, String titleSeries, String title, String quality, String watch, String poster) {
        this.movieId = movieId;
        this.titleSeries = titleSeries;
        this.title = title;
        this.quality = quality;
        this.watch = watch;
        this.poster = poster;
    }

    public String getMovieId() {
        return movieId;
    }

    public void setMovieId(String movieId) {
        this.movieId = movieId;
    }

    public String getTitleSeries() {
        return titleSeries;
    }

    public void setTitleSeries(String titleSeries) {
        this.titleSeries = titleSeries;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getQuality() {
        return quality;
    }

    public void setQuality(String quality) {
        this.quality = quality;
    }

    public String getWatch() {
        return watch;
    }

    public void setWatch(String watch) {
        this.watch = watch;
    }

    public String getPoster() {
        return poster;
    }

    public void setPoster(String poster) {
        this.poster = poster;
    }
}
