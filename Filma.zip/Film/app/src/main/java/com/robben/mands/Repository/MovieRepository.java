package com.robben.mands.Repository;

import android.os.Handler;
import android.os.Looper;

import com.robben.mands.Models.AllMoviesModel;
import com.robben.mands.Models.CastsModel;
import com.robben.mands.Models.StreamModel;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MovieRepository {

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());

    public interface MovieDetailsCallback {
        void onSuccess(MovieDetails details);

        void onError(Exception e);
    }

    public interface StreamLinksCallback {
        void onSuccess(List<StreamModel> streamModels);

        void onError(Exception e);
    }

    public static class MovieDetails {
        public String title;
        public String poster;
        public String imdb;
        public String rating;
        public String adult;
        public String language;
        public String genre;
        public String trailer;
        public String description;
        public String linkGetLinkWatch;
        public String time;
        public String tags;
        public List<CastsModel> castsModels;
        public List<AllMoviesModel> relatedMovies;

        public MovieDetails() {
            castsModels = new ArrayList<>();
            relatedMovies = new ArrayList<>();
        }
    }

    public void getMovieDetails(String url, MovieDetailsCallback callback) {
        executor.execute(() -> {
            try {
                Document doc = Jsoup.connect(url).get();
                MovieDetails details = new MovieDetails();

                Elements elementsTitle = doc
                        .getElementsByClass("entry-title font-size-28 font-weight-bold text-white mb-0");
                Elements elementsPoster = doc.getElementsByClass("col-lg-3 col-md-4 text-center mb-5 mb-md-0");
                Elements elementsImdb = doc
                        .getElementsByClass("font-size-16 text-white mt-2 d-flex align-items-center");
                Elements elementsRating = doc
                        .getElementsByClass("font-size-16 text-white mt-2 d-flex align-items-center");
                Elements elementsAdult = doc.getElementsByClass("badge badge-pill badge-danger font-size-14 mr-3");
                Elements elementsLanguage = doc.getElementsByClass("font-size-16 text-white mt-2");
                Elements elementsGenre = doc.getElementsByClass("badge badge-pill badge-light ml-2");
                Elements elementsTrailer = doc
                        .getElementsByClass("col-lg-2 col-md-3 col-sm-4 d-flex flex-column px-4 px-sm-0");
                Elements elementsDescription = doc.getElementsByClass("text-white font-size-18");
                Elements elementsInfo = doc.getElementsByClass("font-size-16 text-white mt-2");

                details.tags = doc.select("div.font-size-16.d-flex.align-items-center.mt-3 > a")
                        .text().replace("NETFLIX", "نتفليكس")
                        .replace(" ", " | ");

                int sizeInfo = elementsInfo.size();
                for (int i = 0; i < sizeInfo; i++) {
                    details.time = elementsInfo.eq(5).text().replace("مدة الفيلم : ", "");
                }

                Elements elementsLink1 = doc.getElementsByClass("tab-content quality");

                details.title = elementsTitle.text();
                details.poster = elementsPoster.select("a").attr("href");
                details.imdb = elementsImdb.select("a").attr("href");
                details.rating = elementsRating.select("span.mx-2").text();
                details.adult = elementsAdult.text();
                details.language = elementsLanguage.text();
                details.genre = elementsGenre.text();
                details.trailer = elementsTrailer.select("a").attr("href");
                details.description = elementsDescription.text();
                details.linkGetLinkWatch = elementsLink1.select("a").attr("href");

                Elements elementsCast = doc.getElementsByClass("col-lg-auto col-md-4 col-6 mb-12");
                int size = elementsCast.size();
                for (int i = 0; i < size; i++) {
                    String original_name = elementsCast.select("img").eq(i).attr("alt");
                    String details_path = elementsCast.select("a").eq(i).attr("href");
                    String profile_path = elementsCast.select("img").eq(i).attr("src");
                    details.castsModels.add(new CastsModel(original_name, profile_path, details_path));
                }

                Elements elementsMore = doc.getElementsByClass("entry-box entry-box-1");
                Elements ElementDate = doc.getElementsByClass("badge badge-pill badge-secondary ml-1");
                Elements ElementRank = doc.getElementsByClass("label rating");
                Elements ElementQuality = doc.getElementsByClass("label quality");
                Elements ElementType = doc.getElementsByClass("icn add-to-fav mr-4 private hide");
                int size1 = elementsMore.size();
                for (int i = 0; i < size1; i++) {
                    String title = elementsMore.select("div.entry-image").select("div.entry-image img").eq(i)
                            .attr("alt");
                    String poster = elementsMore.select("div.entry-image").select("div.entry-image img").eq(i)
                            .attr("data-src");
                    String stream = elementsMore.select("div.entry-image").select("a").eq(i).attr("href");
                    String type = ElementType.select("a").eq(i).attr("data-type");
                    String date = ElementDate.eq(i).text();
                    String rank = ElementRank.eq(i).text();
                    String quality = ElementQuality.eq(i).text();
                    details.relatedMovies
                            .add(new AllMoviesModel(title, type, date, rank, quality, poster, stream, "0"));
                }

                handler.post(() -> callback.onSuccess(details));
            } catch (Exception e) {
                handler.post(() -> callback.onError(e));
            }
        });
    }

    public void getStreamLinks(String url, String originalUrl, String title, StreamLinksCallback callback) {
        executor.execute(() -> {
            try {
                Document doc = Jsoup.connect(url).get();
                List<StreamModel> streamModels = new ArrayList<>();
                Elements elementsLink = doc.select("source");
                int sizeSource = elementsLink.size();

                for (int i = 0; i < sizeSource; i++) {
                    String quality = elementsLink.eq(i).attr("size");
                    String watch = elementsLink.eq(i).attr("src");
                    streamModels.add(new StreamModel(originalUrl, "", title, quality, watch));
                }

                handler.post(() -> callback.onSuccess(streamModels));
            } catch (Exception e) {
                handler.post(() -> callback.onError(e));
            }
        });
    }
}
