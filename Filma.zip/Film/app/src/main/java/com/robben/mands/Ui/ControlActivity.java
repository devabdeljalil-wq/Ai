package com.robben.mands.Ui;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


import com.robben.mands.R;

import org.w3c.dom.Document;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class ControlActivity extends AppCompatActivity {

    private String controlUrl;
    private Button playPauseButton;
    private SeekBar seekBar, volumeSeekBar;
    private TextView positionText, durationText;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable positionUpdater;
    private boolean isPlaying = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_control);

        controlUrl = getIntent().getStringExtra("CONTROL_URL");

        TextView title = findViewById(R.id.control_title);
        Button backButton = findViewById(R.id.back_button);
        Button rewButton = findViewById(R.id.rew_button);
        playPauseButton = findViewById(R.id.play_pause_button);
        Button ffwdButton = findViewById(R.id.ffwd_button);
        seekBar = findViewById(R.id.seek_bar);
        volumeSeekBar = findViewById(R.id.volume_seek_bar);
        positionText = findViewById(R.id.position_text);
        durationText = findViewById(R.id.duration_text);

        title.setText("DLNA Playback Control");

        backButton.setOnClickListener(v -> finish());

        // Playback controls
        rewButton.setOnClickListener(v -> sendDlnaAction("Seek", "-10"));
        playPauseButton.setOnClickListener(v -> {
            if (isPlaying) {
                sendDlnaAction("Pause");
                playPauseButton.setText("Play");
                isPlaying = false;
            } else {
                sendDlnaAction("Play");
                playPauseButton.setText("Pause");
                isPlaying = true;
            }
        });
        ffwdButton.setOnClickListener(v -> sendDlnaAction("Seek", "10"));

        // Initial state: playing
        playPauseButton.setText("Pause");

        // Seek bar setup
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    positionText.setText(formatTime(progress));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                sendDlnaSeek(seekBar.getProgress());
            }
        });

        // Volume control for DLNA
        volumeSeekBar.setMax(100);
        volumeSeekBar.setProgress(50);
        volumeSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    sendDlnaVolume(progress);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // Start periodic position updates
        startPositionUpdates();
    }

    private void startPositionUpdates() {
        positionUpdater = new Runnable() {
            @Override
            public void run() {
                updatePosition();
                handler.postDelayed(this, 1000); // Update every second
            }
        };
        handler.post(positionUpdater);
    }

    private void updatePosition() {
        new Thread(() -> {
            try {
                String soapRequest = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
                        "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">" +
                        "<s:Body>" +
                        "<u:GetPositionInfo xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\">" +
                        "<InstanceID>0</InstanceID>" +
                        "</u:GetPositionInfo>" +
                        "</s:Body>" +
                        "</s:Envelope>";

                URL url = new URL(controlUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("CONTENT-TYPE", "text/xml; charset=\"utf-8\"");
                conn.setRequestProperty("SOAPACTION", "\"urn:schemas-upnp-org:service:AVTransport:1#GetPositionInfo\"");
                conn.setDoOutput(true);

                OutputStream os = conn.getOutputStream();
                os.write(soapRequest.getBytes());
                os.flush();

                if (conn.getResponseCode() == 200) {
                    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                    DocumentBuilder builder = factory.newDocumentBuilder();
                    Document doc = builder.parse(conn.getInputStream());
                    doc.getDocumentElement().normalize();

                    String relTime = doc.getElementsByTagName("RelTime").item(0).getTextContent();
                    String trackDuration = doc.getElementsByTagName("TrackDuration").item(0).getTextContent();

                    long position = parseTime(relTime);
                    long duration = parseTime(trackDuration);

                    runOnUiThread(() -> {
                        seekBar.setMax((int) duration);
                        seekBar.setProgress((int) position);
                        positionText.setText(formatTime(position));
                        durationText.setText(formatTime(duration));
                    });
                }
                conn.disconnect();
            } catch (Exception e) {
                // Ignore errors to keep updates running
            }
        }).start();
    }

    private long parseTime(String time) {
        String[] parts = time.split(":");
        if (parts.length != 3) return 0;
        long hours = Long.parseLong(parts[0]);
        long minutes = Long.parseLong(parts[1]);
        long seconds = Long.parseLong(parts[2]);
        return TimeUnit.HOURS.toMillis(hours) + TimeUnit.MINUTES.toMillis(minutes) + TimeUnit.SECONDS.toMillis(seconds);
    }

    private String formatTime(long millis) {
        long hours = TimeUnit.MILLISECONDS.toHours(millis);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(millis) % 60;
        long seconds = TimeUnit.MILLISECONDS.toSeconds(millis) % 60;
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }

    private void sendDlnaAction(String action, String... params) {
        new Thread(() -> {
            try {
                String soapAction = String.format("\"urn:schemas-upnp-org:service:AVTransport:1#%s\"", action);
                String soapBody;

                switch (action) {
                    case "Play":
                        soapBody = "<u:Play xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\">" +
                                "<InstanceID>0</InstanceID>" +
                                "<Speed>1</Speed>" +
                                "</u:Play>";
                        break;
                    case "Pause":
                        soapBody = "<u:Pause xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\">" +
                                "<InstanceID>0</InstanceID>" +
                                "</u:Pause>";
                        break;
                    case "Seek":
                        String seekTime = params[0];
                        soapBody = "<u:Seek xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\">" +
                                "<InstanceID>0</InstanceID>" +
                                "<Unit>REL_TIME</Unit>" +
                                "<Target>" + formatSeekTime(seekTime) + "</Target>" +
                                "</u:Seek>";
                        break;
                    default:
                        return;
                }

                String soapRequest = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
                        "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">" +
                        "<s:Body>" + soapBody + "</s:Body>" +
                        "</s:Envelope>";

                URL url = new URL(controlUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("CONTENT-TYPE", "text/xml; charset=\"utf-8\"");
                conn.setRequestProperty("SOAPACTION", soapAction);
                conn.setDoOutput(true);

                OutputStream os = conn.getOutputStream();
                os.write(soapRequest.getBytes());
                os.flush();

                int responseCode = conn.getResponseCode();
                if (responseCode != 200) {
                    runOnUiThread(() -> Toast.makeText(this, action + " failed", Toast.LENGTH_SHORT).show());
                }
                conn.disconnect();
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private void sendDlnaSeek(long position) {
        new Thread(() -> {
            try {
                String soapAction = "\"urn:schemas-upnp-org:service:AVTransport:1#Seek\"";
                String soapBody = "<u:Seek xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\">" +
                        "<InstanceID>0</InstanceID>" +
                        "<Unit>ABS_TIME</Unit>" +
                        "<Target>" + formatTime(position) + "</Target>" +
                        "</u:Seek>";

                String soapRequest = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
                        "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">" +
                        "<s:Body>" + soapBody + "</s:Body>" +
                        "</s:Envelope>";

                URL url = new URL(controlUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("CONTENT-TYPE", "text/xml; charset=\"utf-8\"");
                conn.setRequestProperty("SOAPACTION", soapAction);
                conn.setDoOutput(true);

                OutputStream os = conn.getOutputStream();
                os.write(soapRequest.getBytes());
                os.flush();

                int responseCode = conn.getResponseCode();
                if (responseCode != 200) {
                    runOnUiThread(() -> Toast.makeText(this, "Seek failed", Toast.LENGTH_SHORT).show());
                }
                conn.disconnect();
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Seek error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private void sendDlnaVolume(int volume) {
        new Thread(() -> {
            try {
                String soapAction = "\"urn:schemas-upnp-org:service:RenderingControl:1#SetVolume\"";
                String soapBody = "<u:SetVolume xmlns:u=\"urn:schemas-upnp-org:service:RenderingControl:1\">" +
                        "<InstanceID>0</InstanceID>" +
                        "<Channel>Master</Channel>" +
                        "<DesiredVolume>" + volume + "</DesiredVolume>" +
                        "</u:SetVolume>";

                String soapRequest = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
                        "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">" +
                        "<s:Body>" + soapBody + "</s:Body>" +
                        "</s:Envelope>";

                // Assuming RenderingControl URL is derived; adjust if needed
                URL url = new URL(controlUrl.replace("AVTransport", "RenderingControl"));
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("CONTENT-TYPE", "text/xml; charset=\"utf-8\"");
                conn.setRequestProperty("SOAPACTION", soapAction);
                conn.setDoOutput(true);

                OutputStream os = conn.getOutputStream();
                os.write(soapRequest.getBytes());
                os.flush();

                int responseCode = conn.getResponseCode();
                if (responseCode != 200) {
                    runOnUiThread(() -> Toast.makeText(this, "Volume set failed", Toast.LENGTH_SHORT).show());
                }
                conn.disconnect();
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Volume error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private String formatSeekTime(String seconds) {
        int totalSeconds = Integer.parseInt(seconds);
        int hours = totalSeconds / 3600;
        int minutes = (totalSeconds % 3600) / 60;
        int secs = totalSeconds % 60;
        return String.format("%02d:%02d:%02d", hours, minutes, Math.abs(secs));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(positionUpdater);
    }
}