package com.robben.mands.Ui;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;


import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.navigation.NavigationView;
import com.ismaeldivita.chipnavigation.ChipNavigationBar;


import com.robben.mands.Fragment.CartoonFragment;
import com.robben.mands.Fragment.HomeFragment;
import com.robben.mands.Fragment.MoviesFragment;
import com.robben.mands.Fragment.SeriesFragment;
import com.robben.mands.R;

import com.robben.mands.Utils.Helper;



public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    ChipNavigationBar bottomNav;
    FrameLayout frame;
    ImageView btn_search;
    EditText main_search;
    String name;
    String gmail = "support@devmez.com";
    Helper helper;


    @SuppressLint("NonConstantResourceId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        helper = new Helper(this);


        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("");
        setSupportActionBar(toolbar);
        frame = findViewById(R.id.fragment_frame);
        btn_search = findViewById(R.id.btn_search);

        bottomNav = findViewById(R.id.bottom_nav);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        if (savedInstanceState == null) {
            bottomNav.setItemSelected(R.id.home, true);
            HomeFragment fragment = HomeFragment.newInstance();
            FragmentTransaction ft = getFragmentManager().beginTransaction();
            ft.replace(R.id.fragment_frame, fragment);
            ft.commit();

        }

        bottomNav.setOnItemSelectedListener(id -> {
            Fragment fragment = null;
            if (id == R.id.home) {
                fragment = new HomeFragment();
            } else if (id == R.id.movies) {
                fragment = new MoviesFragment();
            } else if (id == R.id.series) {
                fragment = new SeriesFragment();
            } else if (id == R.id.kids) {
                fragment = new CartoonFragment();
            }

            if (fragment != null) {
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.fragment_frame, fragment);
                ft.commit();
            }
        });

        btn_search.setOnClickListener(view -> showSearch());



    }


    private void showSearch() {

        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(
                this, R.style.BottomSheetDialogTheme
        );


        @SuppressLint("InflateParams") View bottomSheetView = LayoutInflater.from(this)
                .inflate(R.layout.bottom_search, null);

        final Button more0 = bottomSheetView.findViewById(R.id.more0);
        final Button btn_search = bottomSheetView.findViewById(R.id.btn_search);
        main_search = bottomSheetView.findViewById(R.id.main_search);

        final LinearLayout layoutFilters = bottomSheetView.findViewById(R.id.layout_filters);
        final Spinner spinnerSection = bottomSheetView.findViewById(R.id.spinner_section);
        final Spinner spinnerYear = bottomSheetView.findViewById(R.id.spinner_year);
        final Spinner spinnerRating = bottomSheetView.findViewById(R.id.spinner_rating);
        final Spinner spinnerFormats = bottomSheetView.findViewById(R.id.spinner_formats);
        final Spinner spinnerQuality = bottomSheetView.findViewById(R.id.spinner_quality);

        String[] sections = {"القسم: الكل", "أفلام", "مسلسلات"};
        String[] sectionValues = {"0", "movie", "series"};

        String[] years = {"السنة: الكل", "2026", "2025", "2024", "2023", "2022", "2021", "2020", "2019", "2018", "2017", "2016", "2015"};
        String[] yearValues = {"0", "2026", "2025", "2024", "2023", "2022", "2021", "2020", "2019", "2018", "2017", "2016", "2015"};

        String[] ratings = {"التقييم: الكل", "1+", "2+", "3+", "4+", "5+", "6+", "7+", "8+", "9+"};
        String[] ratingValues = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};

        String[] formatsList = {"الصيغة: الكل", "Bluray", "WEB-DL", "HD", "Cam"};
        String[] formatValues = {"0", "bluray", "web-dl", "hd", "cam"};

        String[] qualities = {"الجودة: الكل", "1080p", "720p", "480p"};
        String[] qualityValues = {"0", "1080p", "720p", "480p"};

        ArrayAdapter<String> adapterSection = new ArrayAdapter<>(this, R.layout.spinner_item, sections);
        adapterSection.setDropDownViewResource(R.layout.spinner_dropdown_item);
        spinnerSection.setAdapter(adapterSection);

        ArrayAdapter<String> adapterYear = new ArrayAdapter<>(this, R.layout.spinner_item, years);
        adapterYear.setDropDownViewResource(R.layout.spinner_dropdown_item);
        spinnerYear.setAdapter(adapterYear);

        ArrayAdapter<String> adapterRating = new ArrayAdapter<>(this, R.layout.spinner_item, ratings);
        adapterRating.setDropDownViewResource(R.layout.spinner_dropdown_item);
        spinnerRating.setAdapter(adapterRating);

        ArrayAdapter<String> adapterFormats = new ArrayAdapter<>(this, R.layout.spinner_item, formatsList);
        adapterFormats.setDropDownViewResource(R.layout.spinner_dropdown_item);
        spinnerFormats.setAdapter(adapterFormats);

        ArrayAdapter<String> adapterQuality = new ArrayAdapter<>(this, R.layout.spinner_item, qualities);
        adapterQuality.setDropDownViewResource(R.layout.spinner_dropdown_item);
        spinnerQuality.setAdapter(adapterQuality);

        more0.setVisibility(View.GONE);

        btn_search.setOnClickListener(v -> {
            name = main_search.getText().toString();

            try {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (getCurrentFocus() != null) {
                    imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
                }
            } catch (Exception ignored) {
            }

            main_search.setText("");
            Intent intent = new Intent(MainActivity.this, MainActivitySearchDetails.class);
            intent.putExtra("KEY_MOVIE_NAME", name);
            intent.putExtra("KEY_SECTION", sectionValues[spinnerSection.getSelectedItemPosition()]);
            intent.putExtra("KEY_YEAR", yearValues[spinnerYear.getSelectedItemPosition()]);
            intent.putExtra("KEY_RATING", ratingValues[spinnerRating.getSelectedItemPosition()]);
            intent.putExtra("KEY_FORMATS", formatValues[spinnerFormats.getSelectedItemPosition()]);
            intent.putExtra("KEY_QUALITY", qualityValues[spinnerQuality.getSelectedItemPosition()]);
            startActivity(intent);

            bottomSheetDialog.cancel();
        });

        main_search.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                name = main_search.getText().toString();

                try {
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (getCurrentFocus() != null) {
                        imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
                    }
                } catch (Exception ignored) {
                }
                main_search.setText("");

                Intent intent = new Intent(MainActivity.this, MainActivitySearchDetails.class);
                intent.putExtra("KEY_MOVIE_NAME", name);
                intent.putExtra("KEY_SECTION", sectionValues[spinnerSection.getSelectedItemPosition()]);
                intent.putExtra("KEY_YEAR", yearValues[spinnerYear.getSelectedItemPosition()]);
                intent.putExtra("KEY_RATING", ratingValues[spinnerRating.getSelectedItemPosition()]);
                intent.putExtra("KEY_FORMATS", formatValues[spinnerFormats.getSelectedItemPosition()]);
                intent.putExtra("KEY_QUALITY", qualityValues[spinnerQuality.getSelectedItemPosition()]);
                startActivity(intent);

                bottomSheetDialog.cancel();
                return true;
            }

            return false;
        });


        bottomSheetDialog.setContentView(bottomSheetView);
        bottomSheetDialog.show();


    }

    @SuppressLint("IntentReset")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {

        int id = item.getItemId();
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        if (id == R.id.my_list) {

            Intent intent = new Intent(MainActivity.this, MainActivityFavorite.class);
            startActivity(intent);
        }
        if (id == R.id.my_downloads) {

            Intent intent = new Intent(MainActivity.this, MainActivityDownloads.class);
            startActivity(intent);
        }
        if (id == R.id.nav_rate) {

            String url = "https://play.google.com/store/apps/details?id=" + getPackageName();
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse(url));
            startActivity(i);

        }
        if (id == R.id.nav_share) {

            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name));
            String shareMessage = "أدعوك لتنزيل هذا التطبيق لمشاهدة أي شيء تريده مجانًا ، انقر فوق هذا الرابط أدناه : \n";
            shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" +getPackageName();
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
            startActivity(Intent.createChooser(shareIntent, "choose one"));

        }
        if (id == R.id.nav_help) {
            Intent i = new Intent(Intent.ACTION_SENDTO);
            i.setType("text/plain");
            i.setData(Uri.parse("mailto:"));
            i.putExtra(Intent.EXTRA_EMAIL, new String[]{gmail});
            i.putExtra(Intent.EXTRA_SUBJECT, "تبليغ عن مشكل بالتطبيق");
            i.putExtra(Intent.EXTRA_TEXT, "");
            i.setPackage("com.google.android.gm");
            try {
                startActivity(Intent.createChooser(i, "Send mail..."));
            } catch (android.content.ActivityNotFoundException ex) {
                Toast.makeText(MainActivity.this, "There are no email clients installed.", Toast.LENGTH_SHORT).show();
            }
        }

        if (id == R.id.nav_policy) {
            String url = "https://sites.google.com/view/movieflixapp/accueil";
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse(url));
            startActivity(i);
        }
        if (id == R.id.nav_dmca) {
            dmca();

        }
        if (id == R.id.nav_exit) {
            exit();
        }
        return true;
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        exit();
    }

    private void exit() {

        LayoutInflater layoutInflater = LayoutInflater.from(this);
        View promptView = layoutInflater.inflate(R.layout.popup_layout_exit, null);

        final AlertDialog alertD = new AlertDialog.Builder(this).create();

        TextView yes = promptView.findViewById(R.id.yes);
        TextView no = promptView.findViewById(R.id.no);

        yes.setOnClickListener(v -> {

            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName()));
            startActivity(intent);
            Toast.makeText(MainActivity.this, "شكرا لتقييمك", Toast.LENGTH_SHORT).show();
            alertD.cancel();
        });

        no.setOnClickListener(v -> {
            finish();
            alertD.cancel();
        });

        alertD.setView(promptView);

        alertD.show();

    }

    private void dmca() {

        LayoutInflater layoutInflater = LayoutInflater.from(this);
        View promptView = layoutInflater.inflate(R.layout.popup_layout_dmca, null);
        final AlertDialog alertD = new AlertDialog.Builder(this).create();
        TextView yes = promptView.findViewById(R.id.yes);
        yes.setOnClickListener(v -> alertD.cancel());
        alertD.setView(promptView);
        alertD.show();
    }




}