package com.robben.mands.Ui;

import android.app.AlertDialog;
import android.os.Bundle;
import android.os.StrictMode;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


import com.robben.mands.R;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.KeyStore;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class MainActivityDlna extends AppCompatActivity {

    ListView deviceListView;
    Button refreshButton;
    ArrayAdapter<String> adapter;
    List<String> deviceNames = new ArrayList<>();
    Map<String, String> deviceLocations = new HashMap<>();
    Map<String, String> controlUrls = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_dlna);

        // Allow network operations on main thread for simplicity (not recommended for production)
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        deviceListView = findViewById(R.id.deviceListView);
        refreshButton = findViewById(R.id.refreshButton);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, deviceNames);
        deviceListView.setAdapter(adapter);

        refreshButton.setOnClickListener(v -> discoverDevices());

        deviceListView.setOnItemClickListener((parent, view, position, id) -> {
            String deviceName = deviceNames.get(position);
            String controlUrl = controlUrls.get(deviceName);
            promptForVideoUrl(controlUrl);
        });

        discoverDevices(); // Initial discovery
    }

    private void discoverDevices() {
        deviceNames.clear();
        deviceLocations.clear();
        controlUrls.clear();
        adapter.notifyDataSetChanged();

        new Thread(() -> {
            try {
                DatagramSocket socket = new DatagramSocket();
                socket.setSoTimeout(3000); // 3 seconds timeout
                InetAddress group = InetAddress.getByName("239.255.255.250");
                String searchMessage = "M-SEARCH * HTTP/1.1\r\n" +
                        "HOST: 239.255.255.250:1900\r\n" +
                        "MAN: \"ssdp:discover\"\r\n" +
                        "MX: 3\r\n" +
                        "ST: ssdp:all\r\n\r\n";
                byte[] sendData = searchMessage.getBytes();
                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, group, 1900);
                socket.send(sendPacket);

                byte[] receiveData = new byte[1024];
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                while (true) {
                    try {
                        socket.receive(receivePacket);
                        String response = new String(receivePacket.getData(), 0, receivePacket.getLength());
                        String location = extractLocation(response);
                        if (location != null) {
                            parseDeviceDescription(location);
                        }
                    } catch (Exception e) {
                        break; // Timeout or error, stop listening
                    }
                }
                socket.close();
                runOnUiThread(() -> adapter.notifyDataSetChanged());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    private String extractLocation(String response) {
        for (String line : response.split("\r\n")) {
            if (line.toUpperCase().startsWith("LOCATION:")) {
                return line.substring("LOCATION:".length()).trim();
            }
        }
        return null;
    }

    private void parseDeviceDescription(String location) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new URL(location).openStream());
            doc.getDocumentElement().normalize();

            NodeList deviceNodes = doc.getElementsByTagName("device");
            for (int i = 0; i < deviceNodes.getLength(); i++) {
                Node deviceNode = deviceNodes.item(i);
                if (deviceNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element deviceElement = (Element) deviceNode;
                    String deviceType = deviceElement.getElementsByTagName("deviceType").item(0).getTextContent();
                    if (deviceType.equals("urn:schemas-upnp-org:device:MediaRenderer:1")) {
                        String friendlyName = deviceElement.getElementsByTagName("friendlyName").item(0).getTextContent();
                        String baseUrl = location.substring(0, location.lastIndexOf("/") + 1);
                        String controlUrl = getControlUrl(deviceElement, baseUrl);
                        if (controlUrl != null) {
                            deviceNames.add(friendlyName);
                            deviceLocations.put(friendlyName, location);
                            controlUrls.put(friendlyName, controlUrl);
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String getControlUrl(Element deviceElement, String baseUrl) {
        NodeList serviceNodes = deviceElement.getElementsByTagName("service");
        for (int i = 0; i < serviceNodes.getLength(); i++) {
            Element serviceElement = (Element) serviceNodes.item(i);
            String serviceType = serviceElement.getElementsByTagName("serviceType").item(0).getTextContent();
            if (serviceType.equals("urn:schemas-upnp-org:service:AVTransport:1")) {
                String controlUrl = serviceElement.getElementsByTagName("controlURL").item(0).getTextContent();
                return baseUrl + (controlUrl.startsWith("/") ? controlUrl.substring(1) : controlUrl);
            }
        }
        return null;
    }

    private void promptForVideoUrl(String controlUrl) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enter Video URL");

        final EditText input = new EditText(this);
        input.setText("https://s251d4.downet.net/download/1741046867/67c4f2d37d986/Lazareth.2024.1080p.WEB-DL.AKWAM.mp4");
        builder.setView(input);

        builder.setPositiveButton("Send", (dialog, which) -> {
            String videoUrl = input.getText().toString().trim();
            if (!videoUrl.isEmpty()) {
                sendVideoUrl(controlUrl, videoUrl);
            } else {
                Toast.makeText(MainActivityDlna.this, "URL cannot be empty", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    private void sendVideoUrl(String controlUrl, String videoUrl) {
        new Thread(() -> {
            try {
                // Certificate string
                String certString = "-----BEGIN CERTIFICATE-----\n" +
                        "MIIFVTCCBD2gAwIBAgIQTfuCFUN3ulUOlPlrISUTqDANBgkqhkiG9w0BAQsFADBG\n" +
                        "MQswCQYDVQQGEwJVUzEiMCAGA1UEChMZR29vZ2xlIFRydXN0IFNlcnZpY2VzIExM\n" +
                        "QzETMBEGA1UEAxMKR1RTIENBIDFQNTAeFw0yNDAyMjUwODI2NTVaFw0yNDA1MjUw\n" +
                        "ODI2NTRaMBAxDjAMBgNVBAMTBWFrLnN2MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8A\n" +
                        "MIIBCgKCAQEAq/VGObk60uqjPx3rGRiPsRbfaN2T6TYWQaKINuTp13cTZiEZAo+s\n" +
                        "3o9ZTldIESjXKTycpUgWD25berFCU0a+kJnTOjmbf/Y3Ct/e+067EvWct+bSyPBh\n" +
                        "bcn4ZtkNa5P838vGue7xF4Y83iyBZBsQ7dxRPW/WKIIm+CVv+V2OYP1ClpPIbL8x\n" +
                        "8n+8zcgJ9rMq6kcUdJk4fn34N9Hr0D+6hZYEypC8gwqdOH/KpFzCZChkLxz9Ltr1\n" +
                        "rOcxdHDE6za1S3tAVvtU7KQEz/ylHHcAcUTgU9H5bzQvk/FB32R2i4PkkJFr9AZ7\n" +
                        "M0VmjfnXnBjVuyOtWY3bxeXOtb1cFazHQQIDAQABo4ICczCCAm8wDgYDVR0PAQH/\n" +
                        "BAQDAgWgMBMGA1UdJQQMMAoGCCsGAQUFBwMBMAwGA1UdEwEB/wQCMAAwHQYDVR0O\n" +
                        "BBYEFBR9lCCQqzlx13BTWSbMLl22HxW4MB8GA1UdIwQYMBaAFNX8ng3fHsrdCJeX\n" +
                        "bivFX8Ur9ey4MHgGCCsGAQUFBwEBBGwwajA1BggrBgEFBQcwAYYpaHR0cDovL29j\n" +
                        "c3AucGtpLmdvb2cvcy9ndHMxcDUvckpqallsZ1RBWUUwMQYIKwYBBQUHMAKGJWh0\n" +
                        "dHA6Ly9wa2kuZ29vZy9yZXBvL2NlcnRzL2d0czFwNS5kZXIwGQYDVR0RBBIwEIIF\n" +
                        "YWsuc3aCByouYWsuc3YwIQYDVR0gBBowGDAIBgZngQwBAgEwDAYKKwYBBAHWeQIF\n" +
                        "AzA8BgNVHR8ENTAzMDGgL6AthitodHRwOi8vY3Jscy5wa2kuZ29vZy9ndHMxcDUv\n" +
                        "UktfWEY6LTZaRTguY3JsMIIBAgYKKwYBBAHWeQIEAgSB8wSB8ADuAHUA7s3QZNXb\n" +
                        "Gs7FXLedtM0TojKHRny87N7DUUhZRnEftZsAAAGN35bA7gAABAMARjBEAiAsxrju\n" +
                        "P/fjDwwsRIuurxOdidcPZ53V2VaOBFIcGixi3AIgD8YTX5tR+i5maeh2au9C4hZU\n" +
                        "D04nwXkGTPAD2AsbF8gAdQA7U3d1Pi25gE6LMFsG/kA7Z9hPw/THvQANLXJv4frU\n" +
                        "FwAAAY3flsEAAAAEAwBGMEQCIGEJrIhSi2kS/+6b36yTaHsIhuP9Z4NzDLDG5G1F\n" +
                        "u1tQAiB5N2qcXQH1PkwueBIooimftUjhPP33KUOKVuDacK48GTANBgkqhkiG9w0B\n" +
                        "AQsFAAOCAQEAFpeJBXPSrwEsux2FzqDXxR/VnVWMZyBk8SDhnQ1Nj2gz5FJ2XDjn\n" +
                        "Dy9iLUD3jerT50+ZKsto9CxMqV5YHHupN7thzJnNCjrK6p9sUcGgGxsug8NXgULw\n" +
                        "Cw5kfBW64Jqlu/ewgP4XF0btiL3KyR8H4cMhOILh/qN5gvEnSqLSTiCGAAk35/IF\n" +
                        "XUrwLy0WwL5WFKcezwNBkqTjK61QwdjWXQ221Wrp6CQ5dCXrFu+RE34JMf8uiPlS\n" +
                        "gqP6SA26jxzhdSWCT3MbOhz+uqDzOgIjoMwzR44u8UFYeNlt68h8aozPBWKsoTl5\n" +
                        "U7iHe08VusjqRaDUgCpgSyBVG2KTNMdhIg==\n" +
                        "-----END CERTIFICATE-----";

                // Load the certificate into an X509Certificate object
                CertificateFactory cf = CertificateFactory.getInstance("X.509");
                InputStream caInput = new ByteArrayInputStream(certString.getBytes());
                X509Certificate caCert = (X509Certificate) cf.generateCertificate(caInput);
                caInput.close();

                // Create a KeyStore and add the certificate
                KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
                keyStore.load(null, null); // Initialize empty KeyStore
                keyStore.setCertificateEntry("ca", caCert);

                // Create a TrustManager that trusts the certificate
                TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
                tmf.init(keyStore);

                // Create an SSLContext that uses the TrustManager
                SSLContext sslContext = SSLContext.getInstance("TLS");
                sslContext.init(null, tmf.getTrustManagers(), null);

                // SetAVTransportURI SOAP Request
                String setUriSoap = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
                        "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">" +
                        "<s:Body>" +
                        "<u:SetAVTransportURI xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\">" +
                        "<InstanceID>0</InstanceID>" +
                        "<CurrentURI>" + videoUrl + "</CurrentURI>" +
                        "<CurrentURIMetaData>" +
                        "<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\" " +
                        "xmlns:dc=\"http://www.purl.org/dc/elements/1.1/\">" +
                        "<item id=\"1\" parentID=\"0\" restricted=\"true\">" +
                        "<dc:title>Video</dc:title>" +
                        "<res protocolInfo=\"http-get:*:video/mp4:*\">" + videoUrl + "</res>" +
                        "</item>" +
                        "</DIDL-Lite>" +
                        "</CurrentURIMetaData>" +
                        "</u:SetAVTransportURI>" +
                        "</s:Body>" +
                        "</s:Envelope>";

                URL url = new URL(controlUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                if (conn instanceof HttpsURLConnection) {
                    ((HttpsURLConnection) conn).setSSLSocketFactory(sslContext.getSocketFactory());
                }
                conn.setRequestMethod("POST");
                conn.setRequestProperty("CONTENT-TYPE", "text/xml; charset=\"utf-8\"");
                conn.setRequestProperty("SOAPACTION", "\"urn:schemas-upnp-org:service:AVTransport:1#SetAVTransportURI\"");
                conn.setDoOutput(true);

                OutputStream os = conn.getOutputStream();
                os.write(setUriSoap.getBytes());
                os.flush();

                int responseCode = conn.getResponseCode();
                if (responseCode == 200) {
                    // Play SOAP Request
                    String playSoap = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
                            "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">" +
                            "<s:Body>" +
                            "<u:Play xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\">" +
                            "<InstanceID>0</InstanceID>" +
                            "<Speed>1</Speed>" +
                            "</u:Play>" +
                            "</s:Body>" +
                            "</s:Envelope>";

                    conn = (HttpURLConnection) url.openConnection();
                    if (conn instanceof HttpsURLConnection) {
                        ((HttpsURLConnection) conn).setSSLSocketFactory(sslContext.getSocketFactory());
                    }
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("CONTENT-TYPE", "text/xml; charset=\"utf-8\"");
                    conn.setRequestProperty("SOAPACTION", "\"urn:schemas-upnp-org:service:AVTransport:1#Play\"");
                    conn.setDoOutput(true);

                    os = conn.getOutputStream();
                    os.write(playSoap.getBytes());
                    os.flush();

                    responseCode = conn.getResponseCode();
                    if (responseCode == 200) {
                        runOnUiThread(() -> Toast.makeText(MainActivityDlna.this, "Video sent successfully", Toast.LENGTH_SHORT).show());
                    } else {
                        runOnUiThread(() -> Toast.makeText(MainActivityDlna.this, "Failed to play video", Toast.LENGTH_SHORT).show());
                    }
                } else {
                    runOnUiThread(() -> Toast.makeText(MainActivityDlna.this, "Failed to set video URL", Toast.LENGTH_SHORT).show());
                }
                conn.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(MainActivityDlna.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Cleanup if needed (e.g., close sockets in a production app)
    }
}