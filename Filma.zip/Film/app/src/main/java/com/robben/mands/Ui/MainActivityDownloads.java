package com.robben.mands.Ui;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.robben.mands.Adapter.DownloadsAdapter;
import com.robben.mands.Models.DownloadItem;
import com.robben.mands.R;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivityDownloads extends AppCompatActivity implements DownloadsAdapter.OnDownloadItemClickListener {

    private LinearLayout waitLayout, layout1;
    private RecyclerView recyclerView;
    private DownloadsAdapter adapter;
    private final List<DownloadItem> downloadsList = new ArrayList<>();
    private Button btnBack;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable updateRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_downloads);

        waitLayout = findViewById(R.id.wait);
        layout1 = findViewById(R.id.layout1);
        recyclerView = findViewById(R.id.recyclerview);
        btnBack = findViewById(R.id.back);

        btnBack.setOnClickListener(view -> onBackPressed());

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new DownloadsAdapter(this, downloadsList, this);
        recyclerView.setAdapter(adapter);
    }

    private void startProgressUpdates() {
        updateRunnable = new Runnable() {
            @Override
            public void run() {
                queryDownloads();
                handler.postDelayed(this, 1000);
            }
        };
        handler.post(updateRunnable);
    }

    private void stopProgressUpdates() {
        if (updateRunnable != null) {
            handler.removeCallbacks(updateRunnable);
        }
    }

    private void queryDownloads() {
        executor.execute(() -> {
            List<DownloadItem> list = new ArrayList<>();
            DownloadManager downloadManager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            if (downloadManager != null) {
                DownloadManager.Query query = new DownloadManager.Query();
                Cursor cursor = null;
                try {
                    cursor = downloadManager.query(query);
                    if (cursor != null) {
                        int idCol = cursor.getColumnIndex(DownloadManager.COLUMN_ID);
                        int titleCol = cursor.getColumnIndex(DownloadManager.COLUMN_TITLE);
                        int statusCol = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS);
                        int downloadedCol = cursor.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR);
                        int totalCol = cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES);
                        int localUriCol = cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI);

                        while (cursor.moveToNext()) {
                            long id = cursor.getLong(idCol);
                            String title = cursor.getString(titleCol);
                            int status = cursor.getInt(statusCol);
                            long downloaded = cursor.getLong(downloadedCol);
                            long total = cursor.getLong(totalCol);
                            String localUri = localUriCol != -1 ? cursor.getString(localUriCol) : null;

                            if (title == null) {
                                title = "تحميل غير معروف";
                            }

                            int percentage = 0;
                            if (total > 0) {
                                percentage = (int) ((downloaded * 100) / total);
                            }

                            String poster = getSharedPreferences("downloads_posters", Context.MODE_PRIVATE)
                                    .getString(String.valueOf(id), "");

                            list.add(new DownloadItem(id, title, status, percentage, localUri, poster));
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    if (cursor != null) {
                        cursor.close();
                    }
                }
            }

            handler.post(() -> {
                downloadsList.clear();
                downloadsList.addAll(list);
                adapter.notifyDataSetChanged();

                if (downloadsList.isEmpty()) {
                    waitLayout.setVisibility(View.VISIBLE);
                    layout1.setVisibility(View.GONE);
                } else {
                    waitLayout.setVisibility(View.GONE);
                    layout1.setVisibility(View.VISIBLE);
                }
            });
        });
    }

    @Override
    public void onItemClick(DownloadItem item) {
        if (item.getStatus() == DownloadManager.STATUS_SUCCESSFUL) {
            DownloadManager downloadManager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            Uri fileUri = downloadManager != null ? downloadManager.getUriForDownloadedFile(item.getId()) : null;
            String playUri = fileUri != null ? fileUri.toString() : item.getLocalUri();

            if (playUri != null && !playUri.isEmpty()) {
                Intent intent = new Intent(MainActivityDownloads.this, MainActivityPlayer.class);
                intent.putExtra("KEY_VIDEO_ID", String.valueOf(item.getId()));
                intent.putExtra("KEY_VIDEO_URI", playUri);
                intent.putExtra("KEY_VIDEO_TITLE", item.getTitle());
                intent.putExtra("KEY_VIDEO_TITLE_SERIES", "");
                startActivity(intent);
            } else {
                Toast.makeText(this, "عذرًا، لا يمكن تشغيل هذا الملف.", Toast.LENGTH_SHORT).show();
            }
        } else if (item.getStatus() == DownloadManager.STATUS_FAILED) {
            Toast.makeText(this, "فشل هذا التحميل.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "الرجاء الانتظار حتى يكتمل التحميل لمشاهدته.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDeleteClick(DownloadItem item) {
        executor.execute(() -> {
            DownloadManager downloadManager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            if (downloadManager != null) {
                downloadManager.remove(item.getId());
            }
            handler.post(() -> {
                Toast.makeText(MainActivityDownloads.this, "تم حذف التحميل.", Toast.LENGTH_SHORT).show();
                queryDownloads();
            });
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        startProgressUpdates();
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopProgressUpdates();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }
}
