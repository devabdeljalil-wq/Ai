package com.robben.mands.Ui;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.robben.mands.Adapter.FavoriteAdapter;

import com.robben.mands.Models.AllMoviesModel;
import com.robben.mands.Models.FavoriteModel;
import com.robben.mands.R;
import com.robben.mands.Utils.Helper;
import com.robben.mands.Utils.Utility;
import com.robben.mands.Database.FavoriteDatabase;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

public class MainActivityFavorite extends AppCompatActivity {

    LinearLayout wait,layout1;
    int mNoOfColumns;
    final List<AllMoviesModel> allMoviesModels = new ArrayList<>();
    RecyclerView recyclerView;
    FavoriteAdapter adapter;
    Button result_back;
     FavoriteDatabase favoriteDatabase;
     List<FavoriteModel> checkFavorite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_favorite);
        mNoOfColumns = Utility.calculateNoOfColumns(this);

        wait = findViewById(R.id.wait);
        layout1 = findViewById(R.id.layout1);
        recyclerView = findViewById(R.id.recyclerview);
        result_back = findViewById(R.id.back);

        result_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                onBackPressed();
            }
        });




        FrameLayout bannerLayout = findViewById(R.id.banner);





    }


    @SuppressLint("StaticFieldLeak")
    public class GetAllFavorite extends AsyncTask<Void, Void, List<FavoriteModel>> {
        private final WeakReference<Context> context;

        public GetAllFavorite(Context context) {

            this.context = new WeakReference<>(context);
        }

        @Override
        protected List<FavoriteModel> doInBackground(Void... voids) {
            favoriteDatabase = FavoriteDatabase.getAppDatabase(context.get());

            checkFavorite = favoriteDatabase.favoriteDao().getFavorite();


            return favoriteDatabase.favoriteDao().getFavorite();


        }

        @Override
        protected void onPostExecute(List<FavoriteModel> favoriteModels) {
            super.onPostExecute(favoriteModels);


            if (checkFavorite.isEmpty()) {

                wait.setVisibility(View.VISIBLE);
                layout1.setVisibility(View.GONE);

            } else {

                layout1.setVisibility(View.VISIBLE);
                GridLayoutManager mGridLayoutManager = new GridLayoutManager(MainActivityFavorite.this, mNoOfColumns);
                recyclerView.setLayoutManager(mGridLayoutManager);
                adapter = new FavoriteAdapter(MainActivityFavorite.this,favoriteModels);
                recyclerView.setAdapter(adapter);
            }



        }
    }


    @Override
    protected void onResume() {
        super.onResume();

        new GetAllFavorite(MainActivityFavorite.this).execute();
    }


}