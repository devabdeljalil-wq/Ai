package com.robben.mands.Ui;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatRatingBar;
import androidx.core.widget.ContentLoadingProgressBar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.robben.mands.Adapter.CastsAdapter;
import com.robben.mands.Adapter.DownloadAdapter;
import com.robben.mands.Adapter.HorAllMoviesAdapter;
import com.robben.mands.Adapter.StreamAdapter;
import com.robben.mands.Database.FavoriteDatabase;
import com.robben.mands.Database.TimeDatabase;
import com.robben.mands.Models.AllMoviesModel;
import com.robben.mands.Models.CastsModel;
import com.robben.mands.Models.FavoriteModel;
import com.robben.mands.Models.StreamModel;
import com.robben.mands.Models.TimeModel;
import com.robben.mands.R;
import com.robben.mands.Repository.MovieRepository;
import com.robben.mands.Utils.Helper;
import com.squareup.picasso.Picasso;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivityMoviesDetails extends AppCompatActivity {

    RecyclerView mRecyclerView;
    LinearLayout wait;
    TextView movie_genre, movie_title, movie_date, movie_time, movie_rank, movie_adult, movie_description;
    String urlD, KEY_DETAILS_DATE, KEY_DETAILS_RANK, KEY_DETAILS_QUALITY, KEY_DETAILS_TYPE;
    String title, poster;
    List<CastsModel> castsModels = new ArrayList<>();
    LinearLayoutManager castManager;
    RecyclerView recyclerCast, recyclerMore;
    CastsAdapter adapterCast;
    String linkMovie1080p;
    ImageView movie_poster, movie_cover, result_back;
    LinearLayout bTrailer, bookMark, bookMark1, bSignal, bShare;
    Button bWatch, bDownload;
    FrameLayout result_finish_loading;
    AppCompatRatingBar rating_bar;
    LinearLayoutManager layoutManager;
    List<AllMoviesModel> allMoviesModels = new ArrayList<>();
    List<StreamModel> streamModels = new ArrayList<>();
    StreamAdapter streamAdapter;
    DownloadAdapter downloadAdapter;
    HorAllMoviesAdapter adapter;
    ContentLoadingProgressBar movie_progress;
    @SuppressLint("StaticFieldLeak")
    public static BottomSheetDialog bottomSheetDialog;

    String gmail = "support@devmez.com";
    Helper helper;
    int checkFavorite;
    private final MovieRepository movieRepository = new MovieRepository();

    @SuppressLint("IntentReset")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_movies_details);

        helper = new Helper(this);

        initViews();
        setupListeners();

        urlD = getIntent().getExtras().getString("KEY_DETAILS_URI");
        KEY_DETAILS_DATE = getIntent().getExtras().getString("KEY_DETAILS_DATE");
        KEY_DETAILS_RANK = getIntent().getExtras().getString("KEY_DETAILS_RANK");
        KEY_DETAILS_QUALITY = getIntent().getExtras().getString("KEY_DETAILS_QUALITY");
        KEY_DETAILS_TYPE = getIntent().getExtras().getString("KEY_DETAILS_TYPE");

        movie_date.setText(KEY_DETAILS_DATE);

        checkTimeProgress();

        if (!KEY_DETAILS_RANK.isEmpty()) {
            float a = Float.parseFloat(KEY_DETAILS_RANK);
            rating_bar.setRating(a / 2);
        }

        setupRecyclerViews();

        loadMovieDetails();
    }

    private void initViews() {
        castManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        recyclerMore = findViewById(R.id.result_more_watch);
        recyclerCast = findViewById(R.id.result_cast);
        movie_title = findViewById(R.id.result_title);
        movie_date = findViewById(R.id.result_date);
        movie_time = findViewById(R.id.result_time);
        movie_genre = findViewById(R.id.result_genre);
        movie_rank = findViewById(R.id.result_rank);
        result_back = findViewById(R.id.result_back);
        rating_bar = findViewById(R.id.rating_bar_activity_movie_rating);
        movie_adult = findViewById(R.id.result_adult);
        movie_description = findViewById(R.id.result_des);
        wait = findViewById(R.id.wait);
        result_finish_loading = findViewById(R.id.result_finish_loading);
        movie_progress = findViewById(R.id.movie_progress);
        movie_poster = findViewById(R.id.result_poster);
        movie_cover = findViewById(R.id.result_cover);
        bTrailer = findViewById(R.id.linear_layout_movie_activity_trailer);
        bookMark = findViewById(R.id.linear_layout_activity_movie_my_list);
        bookMark1 = findViewById(R.id.linear_layout_activity_movie_my_list1);
        bSignal = findViewById(R.id.linear_layout_movie_activity_help);
        bShare = findViewById(R.id.linear_layout_movie_activity_share);
        bWatch = findViewById(R.id.result_play_movie);
        bDownload = findViewById(R.id.result_download_movie);
    }

    private void setupListeners() {
        bookMark.setOnClickListener(view -> addToFavorites());
        bookMark1.setOnClickListener(v -> removeFromFavorites());
        result_back.setOnClickListener(view -> onBackPressed());
        bShare.setOnClickListener(v -> shareMovie());
        bSignal.setOnClickListener(v -> reportIssue());
        bWatch.setOnClickListener(v -> ShowStream());
        bDownload.setOnClickListener(v -> ShowDownload());
    }

    private void setupRecyclerViews() {
        recyclerCast.setLayoutManager(castManager);
        adapterCast = new CastsAdapter(castsModels, MainActivityMoviesDetails.this);
        recyclerCast.setAdapter(adapterCast);

        recyclerMore.setLayoutManager(layoutManager);
        adapter = new HorAllMoviesAdapter(allMoviesModels, MainActivityMoviesDetails.this);
        recyclerMore.setAdapter(adapter);
    }

    private void checkTimeProgress() {
        AsyncTask.execute(() -> {
            TimeDatabase timeDatabase = TimeDatabase.getAppDatabase(MainActivityMoviesDetails.this);
            TimeModel timeModel = timeDatabase.timeDao().getTime(urlD);
            if (timeModel != null) {
                runOnUiThread(() -> {
                    movie_progress.setProgress(Integer.parseInt(timeModel.getTime()));
                    bWatch.setText("اكمل الفلم");
                });
            }
        });
    }

    private void addToFavorites() {
        bookMark1.setVisibility(View.VISIBLE);
        bookMark.setVisibility(View.GONE);

        FavoriteModel favoriteModel = new FavoriteModel();
        favoriteModel.setTitle(title);
        favoriteModel.setType(KEY_DETAILS_TYPE);
        favoriteModel.setDate(KEY_DETAILS_DATE);
        favoriteModel.setRank(KEY_DETAILS_RANK);
        favoriteModel.setQuality(KEY_DETAILS_QUALITY);
        favoriteModel.setPoster(poster);
        favoriteModel.setStream(urlD);

        AsyncTask.execute(() -> {
            FavoriteDatabase favoriteDatabase = FavoriteDatabase.getAppDatabase(MainActivityMoviesDetails.this);
            favoriteDatabase.favoriteDao().insert(favoriteModel);
            runOnUiThread(() -> Toast
                    .makeText(MainActivityMoviesDetails.this, "تمت إضافة الى المفضلة", Toast.LENGTH_SHORT).show());
        });
    }

    private void removeFromFavorites() {
        bookMark.setVisibility(View.VISIBLE);
        bookMark1.setVisibility(View.GONE);

        AsyncTask.execute(() -> {
            FavoriteDatabase favoriteDatabase = FavoriteDatabase.getAppDatabase(MainActivityMoviesDetails.this);
            favoriteDatabase.favoriteDao().deleteFavorite(urlD);
            runOnUiThread(() -> Toast
                    .makeText(MainActivityMoviesDetails.this, "تمت الازالة من المفضلة", Toast.LENGTH_LONG).show());
        });
    }

    private void shareMovie() {
        try {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name));
            String shareMessage = "\nLet me recommend you this application\n\n";
            shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + getPackageName() + "\n\n";
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
            startActivity(Intent.createChooser(shareIntent, "choose one"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void reportIssue() {
        Intent i = new Intent(Intent.ACTION_SENDTO);
        i.setType("text/plain");
        i.setData(Uri.parse("mailto:"));
        i.putExtra(Intent.EXTRA_EMAIL, new String[] { gmail });
        i.putExtra(Intent.EXTRA_SUBJECT, "تبليغ عن مشكلة بالفلم");
        i.putExtra(Intent.EXTRA_TEXT, "لقد واجهة مشكلة بهذا الفلم فالرابط لايشتغل المرجو اصلاح المشكل و شكرا لكم . \n" +
                "- اسم الفلم :\n" + title);
        i.setPackage("com.google.android.gm");
        try {
            startActivity(Intent.createChooser(i, "Send mail..."));
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(this, "There are no email clients installed.", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadMovieDetails() {
        movieRepository.getMovieDetails(urlD, new MovieRepository.MovieDetailsCallback() {
            @Override
            public void onSuccess(MovieRepository.MovieDetails details) {
                title = details.title;
                poster = details.poster;

                movie_title.setText(details.title);
                movie_description.setText(details.description);
                movie_adult.setText(details.adult);
                movie_rank.setText(details.rating);
                movie_time.setText(details.time);
                movie_genre.setText(details.tags);

                castsModels.clear();
                castsModels.addAll(details.castsModels);
                adapterCast.notifyDataSetChanged();

                allMoviesModels.clear();
                allMoviesModels.addAll(details.relatedMovies);
                adapter.notifyDataSetChanged();

                checkFavoriteStatus();

                Picasso.get().load(details.poster).into(movie_poster);

                if (details.poster != null) {
                    Uri uri = Uri.parse(details.poster);
                    String token = uri.getLastPathSegment();
                    Picasso.get()
                            .load(helper.getUrlImage() + "/thumb/1920x600/uploads/" + token)
                            .into(movie_cover);
                }

                if (details.linkGetLinkWatch != null) {
                    Uri go1 = Uri.parse(details.linkGetLinkWatch);
                    String goId1 = go1.getLastPathSegment();
                    Pattern pattern = Pattern.compile("(\\d+)");
                    Matcher m = pattern.matcher(urlD);
                    Uri mv1 = Uri.parse(urlD);
                    String movieName = mv1.getLastPathSegment();

                    if (m.find()) {
                        String movieId = m.group();
                        linkMovie1080p = helper.getUrlDefault() + "/watch/" + goId1 + "/" + movieId + "/" + movieName;
                    }
                }

                result_finish_loading.setVisibility(View.VISIBLE);
                wait.setVisibility(View.GONE);
            }

            @Override
            public void onError(Exception e) {
                e.printStackTrace();
                Toast.makeText(MainActivityMoviesDetails.this, "Error loading details", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void checkFavoriteStatus() {
        AsyncTask.execute(() -> {
            FavoriteDatabase favoriteDatabase = FavoriteDatabase.getAppDatabase(MainActivityMoviesDetails.this);
            checkFavorite = favoriteDatabase.favoriteDao().checkFavorite(urlD);
            runOnUiThread(() -> {
                if (checkFavorite == 0) {
                    bookMark1.setVisibility(View.GONE);
                    bookMark.setVisibility(View.VISIBLE);
                } else {
                    bookMark1.setVisibility(View.VISIBLE);
                    bookMark.setVisibility(View.GONE);
                }
            });
        });
    }

    @SuppressLint("NotifyDataSetChanged")
    private void ShowStream() {
        bottomSheetDialog = new BottomSheetDialog(MainActivityMoviesDetails.this, R.style.BottomSheetDialogTheme);
        @SuppressLint("InflateParams")
        View bottomSheetView = LayoutInflater.from(MainActivityMoviesDetails.this)
                .inflate(R.layout.bottom_stream, null);

        LinearLayout waitStream = bottomSheetView.findViewById(R.id.wait);
        RecyclerView mRecyclerViewStream = bottomSheetView.findViewById(R.id.recyclerview);
        mRecyclerViewStream.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

        streamModels.clear();
        streamAdapter = new StreamAdapter(streamModels, MainActivityMoviesDetails.this);
        mRecyclerViewStream.setAdapter(streamAdapter);

        bottomSheetDialog.setContentView(bottomSheetView);
        bottomSheetDialog.show();

        if (linkMovie1080p != null) {
            movieRepository.getStreamLinks(linkMovie1080p, urlD, title, new MovieRepository.StreamLinksCallback() {
                @Override
                public void onSuccess(List<StreamModel> models) {
                    streamModels.clear();
                    for (StreamModel m : models) {
                        m.setPoster(poster);
                        streamModels.add(m);
                    }
                    streamAdapter.notifyDataSetChanged();

                    if (streamModels.isEmpty()) {
                        waitStream.setVisibility(View.VISIBLE);
                    } else {
                        waitStream.setVisibility(View.GONE);
                        mRecyclerViewStream.setVisibility(View.VISIBLE);
                    }
                }

                @Override
                public void onError(Exception e) {
                    e.printStackTrace();
                    waitStream.setVisibility(View.VISIBLE);
                }
            });
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    private void ShowDownload() {
        bottomSheetDialog = new BottomSheetDialog(MainActivityMoviesDetails.this, R.style.BottomSheetDialogTheme);
        @SuppressLint("InflateParams")
        View bottomSheetView = LayoutInflater.from(MainActivityMoviesDetails.this)
                .inflate(R.layout.bottom_stream, null);

        LinearLayout waitDownload = bottomSheetView.findViewById(R.id.wait);
        RecyclerView mRecyclerViewDownload = bottomSheetView.findViewById(R.id.recyclerview);
        mRecyclerViewDownload.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

        streamModels.clear();
        downloadAdapter = new DownloadAdapter(streamModels, MainActivityMoviesDetails.this);
        mRecyclerViewDownload.setAdapter(downloadAdapter);

        bottomSheetDialog.setContentView(bottomSheetView);
        bottomSheetDialog.show();

        if (linkMovie1080p != null) {
            movieRepository.getStreamLinks(linkMovie1080p, urlD, title, new MovieRepository.StreamLinksCallback() {
                @Override
                public void onSuccess(List<StreamModel> models) {
                    streamModels.clear();
                    for (StreamModel m : models) {
                        m.setPoster(poster);
                        streamModels.add(m);
                    }
                    downloadAdapter.notifyDataSetChanged();

                    if (streamModels.isEmpty()) {
                        waitDownload.setVisibility(View.VISIBLE);
                    } else {
                        waitDownload.setVisibility(View.GONE);
                        mRecyclerViewDownload.setVisibility(View.VISIBLE);
                    }
                }

                @Override
                public void onError(Exception e) {
                    e.printStackTrace();
                    waitDownload.setVisibility(View.VISIBLE);
                }
            });
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        checkTimeProgress();
    }
}