package com.robben.mands.Ui;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.ui.AspectRatioFrameLayout;
import com.google.android.exoplayer2.ui.StyledPlayerView;
import com.robben.mands.Database.TimeDatabase;
import com.robben.mands.Models.TimeModel;
import com.robben.mands.R;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class MainActivityPlayer extends AppCompatActivity {

    int seek;
    int FirstSeek = 1;

    private StyledPlayerView playerView;
    private ExoPlayer player;
    private int count = 1;
    private final Handler mHideHandler = new Handler();
    private final Runnable mHideRunnable = () -> playerView.setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LOW_PROFILE | View.SYSTEM_UI_FLAG_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);

    List<String> deviceNames = new ArrayList<>();
    Map<String, String> controlUrls = new HashMap<>();
    Set<String> deviceUuids = new HashSet<>();
    private static final int MAX_DEVICES = 5; // Maximum number of devices to discover

    String videoTitle, videoTitleSeries, videoUri, KEY_VIDEO_ID;

    TextView title;

    @SuppressLint({"MissingInflatedId", "StaticFieldLeak", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_player);

        Intent data = getIntent();
        KEY_VIDEO_ID = data.getExtras().getString("KEY_VIDEO_ID");

        title = findViewById(R.id.txt_title);

        videoUri = data.getExtras().getString("KEY_VIDEO_URI");
        videoTitle = data.getExtras().getString("KEY_VIDEO_TITLE");
        videoTitleSeries = data.getExtras().getString("KEY_VIDEO_TITLE_SERIES");

        if (videoTitleSeries.isEmpty()) {
            title.setText(videoTitle);
        } else {
            title.setText(videoTitleSeries + "\n" + videoTitle);
        }

        AsyncTask.execute(() -> {
            TimeDatabase timeDatabase = TimeDatabase.getAppDatabase(MainActivityPlayer.this);
            TimeModel timeModel = timeDatabase.timeDao().getTime(KEY_VIDEO_ID);

            if (timeModel != null) {
                seek = Integer.parseInt(timeModel.getTime());
            }
        });

        playerView = findViewById(R.id.player_view);
        player = new ExoPlayer.Builder(this).build();

        playerView.setPlayer(player);
        MediaItem mediaItem = MediaItem.fromUri(videoUri);
        player.setMediaItem(mediaItem);
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);

        player.prepare();
        player.setPlayWhenReady(true);

        findViewById(R.id.resize_player).setOnClickListener(v -> {
            switch (count) {
                case 1:
                    playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FILL);
                    count++;
                    break;
                case 2:
                    playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_ZOOM);
                    count++;
                    break;
                case 3:
                    playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
                    count = 1;
                    break;
            }
        });

        findViewById(R.id.speed_player).setOnClickListener(v -> {
            switch (count) {
                case 1:
                    count++;
                    player.setPlaybackParameters(player.getPlaybackParameters().withSpeed(1.5f));
                    ((TextView) findViewById(R.id.player_speed_text)).setText("السرعة: 1.5x");
                    break;
                case 2:
                    player.setPlaybackParameters(player.getPlaybackParameters().withSpeed(2.0f));
                    ((TextView) findViewById(R.id.player_speed_text)).setText("السرعة: 2x");
                    count++;
                    break;
                case 3:
                    player.setPlaybackParameters(player.getPlaybackParameters().withSpeed(1.0f));
                    ((TextView) findViewById(R.id.player_speed_text)).setText("السرعة: 1x");
                    count = 1;
                    break;
            }
        });

        findViewById(R.id.dlna_player).setOnClickListener(v -> discoverDevicesWithProgress(videoUri));

        findViewById(R.id.btn_back).setOnClickListener(v -> onBackPressed());

        findViewById(R.id.lock_player).setOnClickListener(v -> {
            findViewById(R.id.ui_control_player).setVisibility(View.GONE);
            findViewById(R.id.lock_player1).setVisibility(View.VISIBLE);
        });

        findViewById(R.id.lock_player1).setOnClickListener(v -> {
            findViewById(R.id.ui_control_player).setVisibility(View.VISIBLE);
            findViewById(R.id.lock_player1).setVisibility(View.GONE);
        });

        SeekBar volumeSeekBar = findViewById(R.id.volume_seekbar);
        volumeSeekBar.setMax(100);
        volumeSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                float volume = progress / 100f;
                player.setVolume(volume);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        SeekBar brightnessSeekBar = findViewById(R.id.brightness_seekbar);
        brightnessSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                float backLightValue = progress / 100f;
                android.view.WindowManager.LayoutParams layoutParams = getWindow().getAttributes();
                layoutParams.screenBrightness = backLightValue;
                getWindow().setAttributes(layoutParams);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_READY) {
                    if (FirstSeek == 1) {
                        if (seek != 0) {
                            int timeMs = (int) player.getDuration();
                            int totalSeconds = timeMs * seek / 100;
                            player.seekTo(totalSeconds);
                        }
                        FirstSeek++;
                    }
                }
                if (state == Player.STATE_ENDED) {
                    player.seekTo(0);
                    player.setPlayWhenReady(true);
                }
            }
        });
    }

    private void discoverDevicesWithProgress(String videoURL) {
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("جارٍ البحث عن أجهزة DLNA..."); // "Searching for DLNA devices..."
        progressDialog.setCancelable(false);
        progressDialog.show();

        deviceNames.clear();
        controlUrls.clear();
        deviceUuids.clear();

        new Thread(() -> {
            try {
                DatagramSocket socket = new DatagramSocket();
                socket.setSoTimeout(1000); // Reduce timeout to 1 second
                InetAddress group = InetAddress.getByName("239.255.255.250");
                String searchMessage = "M-SEARCH * HTTP/1.1\r\n" +
                        "HOST: 239.255.255.250:1900\r\n" +
                        "MAN: \"ssdp:discover\"\r\n" +
                        "MX: 1\r\n" + // Reduce MX to 1 for faster response
                        "ST: urn:schemas-upnp-org:device:MediaRenderer:1\r\n\r\n"; // Specific search for MediaRenderer
                byte[] sendData = searchMessage.getBytes();
                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, group, 1900);
                socket.send(sendPacket);

                byte[] receiveData = new byte[1024];
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                int devicesFound = 0;
                while (devicesFound < MAX_DEVICES) { // Stop after finding 5 devices
                    try {
                        socket.receive(receivePacket);
                        String response = new String(receivePacket.getData(), 0, receivePacket.getLength());
                        String location = extractLocation(response);
                        if (location != null) {
                            parseDeviceDescription(location);
                            devicesFound++;
                        }
                    } catch (Exception e) {
                        break; // Timeout or other error
                    }
                }
                socket.close();

                runOnUiThread(() -> {
                    progressDialog.dismiss();
                    showDeviceDialog(videoURL);
                });
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> {
                    progressDialog.dismiss();
                    Toast.makeText(this, "خطأ أثناء البحث عن الأجهزة", Toast.LENGTH_SHORT).show(); // "Error discovering devices"
                });
            }
        }).start();
    }

    private String extractLocation(String response) {
        for (String line : response.split("\r\n")) {
            if (line.toUpperCase().startsWith("LOCATION:")) {
                return line.substring("LOCATION:".length()).trim();
            }
        }
        return null;
    }

    private void parseDeviceDescription(String location) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new URL(location).openStream());
            doc.getDocumentElement().normalize();

            NodeList deviceNodes = doc.getElementsByTagName("device");
            for (int i = 0; i < deviceNodes.getLength(); i++) {
                Node deviceNode = deviceNodes.item(i);
                if (deviceNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element deviceElement = (Element) deviceNode;
                    String deviceType = deviceElement.getElementsByTagName("deviceType").item(0).getTextContent();
                    if (deviceType.equals("urn:schemas-upnp-org:device:MediaRenderer:1")) {
                        String uuid = deviceElement.getElementsByTagName("UDN").item(0).getTextContent();
                        if (!deviceUuids.contains(uuid)) {
                            String friendlyName = deviceElement.getElementsByTagName("friendlyName").item(0).getTextContent();
                            String baseUrl = location.substring(0, location.lastIndexOf("/") + 1);
                            String controlUrl = getControlUrl(deviceElement, baseUrl);
                            if (controlUrl != null) {
                                deviceNames.add(friendlyName);
                                controlUrls.put(friendlyName, controlUrl);
                                deviceUuids.add(uuid);
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String getControlUrl(Element deviceElement, String baseUrl) {
        NodeList serviceNodes = deviceElement.getElementsByTagName("service");
        for (int i = 0; i < serviceNodes.getLength(); i++) {
            Element serviceElement = (Element) serviceNodes.item(i);
            String serviceType = serviceElement.getElementsByTagName("serviceType").item(0).getTextContent();
            if (serviceType.equals("urn:schemas-upnp-org:service:AVTransport:1")) {
                String controlUrl = serviceElement.getElementsByTagName("controlURL").item(0).getTextContent();
                return baseUrl + (controlUrl.startsWith("/") ? controlUrl.substring(1) : controlUrl);
            }
        }
        return null;
    }

    private void showDeviceDialog(String videoURL) {
        if (deviceNames.isEmpty()) {
            Toast.makeText(this, "لم يتم العثور على أجهزة MediaRenderer", Toast.LENGTH_SHORT).show(); // "No MediaRenderer devices found"
            return;
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("اختر جهاز DLNA"); // "Select DLNA Device"
        builder.setItems(deviceNames.toArray(new String[0]), (dialog, which) -> {
            String selectedDevice = deviceNames.get(which);
            String controlUrl = controlUrls.get(selectedDevice);
            sendVideoUrl(controlUrl, videoURL);
        });
        builder.setNegativeButton("إلغاء", (dialog, which) -> dialog.dismiss()); // "Cancel"
        builder.show();
    }

    private void sendVideoUrl(String controlUrl, String videoUrl) {
        new Thread(() -> {
            try {
                String setUriSoap = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
                        "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">" +
                        "<s:Body>" +
                        "<u:SetAVTransportURI xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\">" +
                        "<InstanceID>0</InstanceID>" +
                        "<CurrentURI>" + videoUrl + "</CurrentURI>" +
                        "<CurrentURIMetaData>" +
                        "<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\" " +
                        "xmlns:dc=\"http://www.purl.org/dc/elements/1.1/\">" +
                        "<item id=\"1\" parentID=\"0\" restricted=\"true\">" +
                        "<dc:title>Video</dc:title>" +
                        "<res protocolInfo=\"http-get:*:video/mp4:*\">" + videoUrl + "</res>" +
                        "</item>" +
                        "</DIDL-Lite>" +
                        "</CurrentURIMetaData>" +
                        "</u:SetAVTransportURI>" +
                        "</s:Body>" +
                        "</s:Envelope>";

                URL url = new URL(controlUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("CONTENT-TYPE", "text/xml; charset=\"utf-8\"");
                conn.setRequestProperty("SOAPACTION", "\"urn:schemas-upnp-org:service:AVTransport:1#SetAVTransportURI\"");
                conn.setDoOutput(true);

                OutputStream os = conn.getOutputStream();
                os.write(setUriSoap.getBytes());
                os.flush();

                int responseCode = conn.getResponseCode();
                if (responseCode == 200) {
                    String playSoap = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
                            "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">" +
                            "<s:Body>" +
                            "<u:Play xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\">" +
                            "<InstanceID>0</InstanceID>" +
                            "<Speed>1</Speed>" +
                            "</u:Play>" +
                            "</s:Body>" +
                            "</s:Envelope>";

                    conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("CONTENT-TYPE", "text/xml; charset=\"utf-8\"");
                    conn.setRequestProperty("SOAPACTION", "\"urn:schemas-upnp-org:service:AVTransport:1#Play\"");
                    conn.setDoOutput(true);

                    os = conn.getOutputStream();
                    os.write(playSoap.getBytes());
                    os.flush();

                    responseCode = conn.getResponseCode();
                    if (responseCode == 200) {
                        runOnUiThread(() -> {
                            Toast.makeText(this, "تم إرسال الفيديو إلى جهاز DLNA", Toast.LENGTH_SHORT).show(); // "Video sent to DLNA device"
                            Intent intent = new Intent(MainActivityPlayer.this, ControlActivity.class);
                            intent.putExtra("CONTROL_URL", controlUrl);
                            intent.putExtra("VIDEO_URL", videoUrl);
                            startActivity(intent);
                        });
                    } else {
                        runOnUiThread(() -> Toast.makeText(this, "فشل تشغيل الفيديو على DLNA", Toast.LENGTH_SHORT).show()); // "Failed to play video on DLNA"
                    }
                } else {
                    runOnUiThread(() -> Toast.makeText(this, "فشل تعيين عنوان URL للفيديو على DLNA", Toast.LENGTH_SHORT).show()); // "Failed to set video URL on DLNA"
                }
                conn.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(this, "خطأ: " + e.getMessage(), Toast.LENGTH_SHORT).show()); // "Error: " + message
            }
        }).start();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) {
            player.setPlayWhenReady(false);
            player.release();
            player = null;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        pausePlayer();
        playerView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LOW_PROFILE | View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);

        // Get the buffered percentage on the main thread to avoid IllegalStateException
        String bufferedPercentage = player != null ? String.valueOf(player.getBufferedPercentage()) : "0";

        TimeModel timeModel = new TimeModel();
        timeModel.setStream(KEY_VIDEO_ID);
        timeModel.setTime(bufferedPercentage);

        // Perform database operations in AsyncTask without accessing the player
        AsyncTask.execute(() -> {
            TimeDatabase timeDatabase = TimeDatabase.getAppDatabase(MainActivityPlayer.this);

            if (timeDatabase.timeDao().checkTime(KEY_VIDEO_ID) == 0) {
                timeDatabase.timeDao().insert(timeModel);
            } else {
                timeDatabase.timeDao().updateTime(bufferedPercentage, KEY_VIDEO_ID);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        playerView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LOW_PROFILE | View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        resumePlayer();
        playerView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LOW_PROFILE | View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mHideHandler != null) {
            mHideHandler.removeCallbacks(mHideRunnable);
        }
    }

    private void pausePlayer() {
        if (player != null) {
            player.setPlayWhenReady(false);
            player.getPlaybackState();
        }
    }

    private void resumePlayer() {
        if (player != null) {
            player.setPlayWhenReady(true);
            player.getPlaybackState();
        }
    }
}