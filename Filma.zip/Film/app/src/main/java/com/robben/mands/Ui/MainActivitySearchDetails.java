package com.robben.mands.Ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.robben.mands.Adapter.AllMoviesAdapter;

import com.robben.mands.Models.AllMoviesModel;
import com.robben.mands.R;
import com.robben.mands.Utils.Helper;
import com.robben.mands.Utils.Utility;


import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainActivitySearchDetails extends AppCompatActivity {

    RecyclerView mRecyclerView;
    AllMoviesAdapter adapter0;
    ProgressBar progress0;

    int page = 1;
    int mNoOfColumns;
    List<AllMoviesModel> allMoviesModels0 = new ArrayList<>();
    String KEY_MOVIE_NAME;
    String KEY_SECTION = "0";
    String KEY_YEAR = "0";
    String KEY_RATING = "0";
    String KEY_FORMATS = "0";
    String KEY_QUALITY = "0";
    LinearLayout layout1, wait,noFound;
    TextView title;
     Helper helper;
     int size;
    Button result_back;
    LinearLayout bannerLayout;


    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_search_details);

         helper =new Helper(this);
        mNoOfColumns = Utility.calculateNoOfColumns(this);

        wait = findViewById(R.id.wait);
        result_back = findViewById(R.id.back);

        layout1 = findViewById(R.id.layout1);
        noFound = findViewById(R.id.noFound);
        title = findViewById(R.id.title);
        String query = getIntent().getExtras().getString("KEY_MOVIE_NAME");
        if (query == null || query.isEmpty()) {
            title.setText("بحث مصفى");
        } else {
            title.setText("كلمة البحث : " + query);
        }


        mRecyclerView = findViewById(R.id.home_expanded_recycler);
        progress0 = findViewById(R.id.progress_circular0);


        KEY_MOVIE_NAME = getIntent().getExtras().getString("KEY_MOVIE_NAME");
        KEY_SECTION = getIntent().getExtras().getString("KEY_SECTION", "0");
        KEY_YEAR = getIntent().getExtras().getString("KEY_YEAR", "0");
        KEY_RATING = getIntent().getExtras().getString("KEY_RATING", "0");
        KEY_FORMATS = getIntent().getExtras().getString("KEY_FORMATS", "0");
        KEY_QUALITY = getIntent().getExtras().getString("KEY_QUALITY", "0");


        GridLayoutManager mGridLayoutManager = new GridLayoutManager(this, mNoOfColumns);
        mRecyclerView.setLayoutManager(mGridLayoutManager);

        adapter0 = new AllMoviesAdapter(allMoviesModels0, this);
        mRecyclerView.setAdapter(adapter0);


        Content content = new Content();
        content.execute();


        result_back.setOnClickListener(view -> onBackPressed());

        FrameLayout bannerLayout = findViewById(R.id.banner);


    }

    @SuppressLint("StaticFieldLeak")
    private class Content extends AsyncTask<Void, Void, Void> {


        @Override
        protected Void doInBackground(Void... voids) {

            try {

                String url1 = helper.getUrlDefault() + "/search?q=" + KEY_MOVIE_NAME
                        + "&section=" + KEY_SECTION
                        + "&year=" + KEY_YEAR
                        + "&rating=" + KEY_RATING
                        + "&formats=" + KEY_FORMATS
                        + "&quality=" + KEY_QUALITY
                        + "&page=" + page++;
                Document doc = Jsoup.connect(url1).get();

                Elements data = doc.getElementsByClass("col-lg-auto col-md-4 col-6 mb-12");
                Elements ElementDate = doc.getElementsByClass("badge badge-pill badge-secondary ml-1");
                Elements ElementRank = doc.getElementsByClass("label rating");
                Elements ElementQuality = doc.getElementsByClass("label quality");
                Elements ElementType = doc.getElementsByClass("icn add-to-fav mr-4 private hide");

                 size = data.size();
                for (int i = 0; i < size; i++) {

                    String title = data.select("div.entry-image")
                            .select("div.entry-image img")
                            .eq(i)
                            .attr("alt");
                    String poster = data.select("div.entry-image")
                            .select("div.entry-image img")
                            .eq(i)
                            .attr("data-src");
                    String stream = data.select("div.entry-image")
                            .select("a")
                            .eq(i)
                            .attr("href");

                    String type = ElementType
                            .select("a")
                            .eq(i)
                            .attr("data-type");
                    String date = ElementDate.eq(i)
                            .text();
                    String rank = ElementRank.eq(i)
                            .text();
                    String quality = ElementQuality.eq(i)
                            .text();

                    if (type.equals("movie")||type.equals("series")){
                        allMoviesModels0.add(new AllMoviesModel(title, type, date, rank, quality, poster, stream,"0"));

                    }

                }

            } catch (IOException e) {
                e.printStackTrace();
            }


            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @SuppressLint("NotifyDataSetChanged")
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

                if (size==0){
                    wait.setVisibility(View.GONE);
                    noFound.setVisibility(View.VISIBLE);

                }else {
                    progress0.setVisibility(View.GONE);
                    adapter0.notifyDataSetChanged();
                    wait.setVisibility(View.GONE);
                    layout1.setVisibility(View.VISIBLE);
                }

        }
    }

}