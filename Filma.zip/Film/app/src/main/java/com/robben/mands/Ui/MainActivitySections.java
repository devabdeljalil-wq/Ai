package com.robben.mands.Ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.robben.mands.Adapter.AllMoviesAdapter;

import com.robben.mands.Models.AllMoviesModel;
import com.robben.mands.R;
import com.robben.mands.Utils.Helper;
import com.robben.mands.Utils.Utility;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivitySections extends AppCompatActivity {
    RecyclerView mRecyclerView;
    AllMoviesAdapter adapter0;
    ProgressBar progress0;

    int page = 1;
    int mNoOfColumns;
    List<AllMoviesModel> allMoviesModels0 = new ArrayList<>();
    String KEY_GENRE_ID, KEY_GENRE_TYPE;
    LinearLayout layout1, wait;
    TextView title;
    Helper helper;
     String htmlData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_sections);

        helper = new Helper(this);
        mNoOfColumns = Utility.calculateNoOfColumns(this);

        wait = findViewById(R.id.wait);
        layout1 = findViewById(R.id.layout1);
        title = findViewById(R.id.title);
        title.setText("القسم : " + getIntent().getExtras().getString("KEY_GENRE_TITLE"));

        mRecyclerView = findViewById(R.id.home_expanded_recycler);
        final Button more0 = findViewById(R.id.more0);
        progress0 = findViewById(R.id.progress_circular0);

        KEY_GENRE_ID = getIntent().getExtras().getString("KEY_GENRE_ID");
        KEY_GENRE_TYPE = getIntent().getExtras().getString("KEY_GENRE_TYPE");


        GridLayoutManager mGridLayoutManager = new GridLayoutManager(this, mNoOfColumns);
        mRecyclerView.setLayoutManager(mGridLayoutManager);

        adapter0 = new AllMoviesAdapter(allMoviesModels0, this);
        mRecyclerView.setAdapter(adapter0);




        more0.setOnClickListener(v -> onBackPressed());

        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);

                if (!recyclerView.canScrollVertically(1) && newState == RecyclerView.SCROLL_STATE_IDLE) {
                    progress0.setVisibility(View.VISIBLE);

                    GetJsonAsync getJson = new GetJsonAsync();
                    getJson.execute();

                }
            }
        });

        FrameLayout bannerLayout = findViewById(R.id.banner);

        GetJsonAsync getJson = new GetJsonAsync();
        getJson.execute();


    }

    private class GetJsonAsync extends AsyncTask <String, Void, String> {

        @Override
        protected void onPreExecute() {
            // Do stuff before the operation
        }

        @Override
        protected String doInBackground(String... params){
            URL google = null;
            try {
                google = new URL(helper.getUrlDefault() + "/" + KEY_GENRE_TYPE + "?section=" + KEY_GENRE_ID + "&page=" + page++);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            BufferedReader in = null;
            try {
                in = new BufferedReader(new InputStreamReader(google.openStream()));
            } catch (IOException e) {
                e.printStackTrace();
            }
            String input = null;
            StringBuffer stringBuffer = new StringBuffer();
            while (true)
            {
                try {
                    if (!((input = in.readLine()) != null)) break;
                } catch (IOException e) {
                    e.printStackTrace();
                }
                stringBuffer.append(input);
            }
            try {
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            htmlData = stringBuffer.toString();



            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            Content content = new Content();
            content.execute();
        }
    }
    @SuppressLint("StaticFieldLeak")
    private class Content extends AsyncTask<Void, Void, Void> {


        @Override
        protected Void doInBackground(Void... voids) {

            String url1 = helper.getUrlDefault() + "/" + KEY_GENRE_TYPE + "?section=" + KEY_GENRE_ID + "&page=" + page++;
            Document doc = Jsoup.parse(htmlData);

            Elements data = doc.getElementsByClass("col-lg-auto col-md-4 col-6 mb-12");
            Elements ElementDate = doc.getElementsByClass("badge badge-pill badge-secondary ml-1");
            Elements ElementRank = doc.getElementsByClass("label rating");
            Elements ElementQuality = doc.getElementsByClass("label quality");
            Elements ElementType = doc.getElementsByClass("icn add-to-fav mr-4 private hide");

            int size = data.size();
            for (int i = 0; i < size; i++) {

                String title = data.select("div.entry-image")
                        .select("div.entry-image img")
                        .eq(i)
                        .attr("alt");
                String poster = data.select("div.entry-image")
                        .select("div.entry-image img")
                        .eq(i)
                        .attr("data-src");
                String stream = data.select("div.entry-image")
                        .select("a")
                        .eq(i)
                        .attr("href");

                String type = ElementType
                        .select("a")
                        .eq(i)
                        .attr("data-type");
                String date = ElementDate.eq(i)
                        .text();
                String rank = ElementRank.eq(i)
                        .text();
                String quality = ElementQuality.eq(i)
                        .text();
                allMoviesModels0.add(new AllMoviesModel(title, type, date, rank, quality, poster, stream, "0"));

            }


            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @SuppressLint("NotifyDataSetChanged")
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

                progress0.setVisibility(View.GONE);
                adapter0.notifyDataSetChanged();

                wait.setVisibility(View.GONE);
                layout1.setVisibility(View.VISIBLE);


        }
    }

}