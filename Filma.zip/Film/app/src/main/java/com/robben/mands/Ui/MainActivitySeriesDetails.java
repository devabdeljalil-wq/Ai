package com.robben.mands.Ui;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatRatingBar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.robben.mands.Adapter.CastsAdapter;
import com.robben.mands.Adapter.EpisodesAdapter;
import com.robben.mands.Adapter.HorAllMoviesAdapter;

import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;

import com.robben.mands.Models.AllMoviesModel;
import com.robben.mands.Models.CastsModel;
import com.robben.mands.Models.EpisodesModel;
import com.robben.mands.Models.FavoriteModel;
import com.robben.mands.R;
import com.robben.mands.Utils.Helper;
import com.robben.mands.Database.FavoriteDatabase;
import com.robben.mands.Database.TimeDatabase;
import com.squareup.picasso.Picasso;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivitySeriesDetails extends AppCompatActivity {
    LinearLayout wait;

    TextView movie_genre, movie_title, movie_date, movie_time, movie_rank, movie_adult, movie_description;
    String urlD, KEY_DETAILS_DATE, KEY_DETAILS_RANK, KEY_DETAILS_QUALITY, KEY_DETAILS_TYPE;
    String title, poster, imdb, rating, adult, language, genre, trailer, description;
    List<CastsModel> castsModels = new ArrayList<>();
    LinearLayoutManager castManager;
    RecyclerView recyclerCast, recyclerMore, recyclerEpisodes;
    CastsAdapter adapterCast;
    ImageView movie_poster, movie_cover, result_back;
    LinearLayout bTrailer, bookMark, bookMark1, bSignal, bShare;
    FrameLayout result_finish_loading;
    AppCompatRatingBar rating_bar;
    Document doc;
    LinearLayoutManager layoutManager;
    List<AllMoviesModel> allMoviesModels = new ArrayList<>();
    List<EpisodesModel> episodesModels = new ArrayList<>();
    EpisodesAdapter episodesAdapter;
    HorAllMoviesAdapter adapter;
    Spinner spinnerEpisodeSort, spinnerEpisodePage;
    final List<EpisodesModel> masterEpisodesList = new ArrayList<>();
    boolean isSettingUpPageSpinner = false;
    LinearLayout result_series_parent;
    String time;
    String gmail = "support@devmez.com";
    Helper helper;
    String tags;
    FavoriteDatabase favoriteDatabase;
    int checkFavorite;

    @SuppressLint("IntentReset")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_series_details);

        helper = new Helper(this);

        spinnerEpisodeSort = findViewById(R.id.spinner_episode_sort);
        spinnerEpisodePage = findViewById(R.id.spinner_episode_page);

        String[] sortOptions = {"الترتيب: من الأول", "الترتيب: من الأخير"};
        ArrayAdapter<String> sortAdapter = new ArrayAdapter<>(this, R.layout.spinner_item, sortOptions);
        sortAdapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        spinnerEpisodeSort.setAdapter(sortAdapter);

        spinnerEpisodeSort.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                setupPageSpinner(masterEpisodesList.size(), position == 0);
                updateEpisodeList();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        spinnerEpisodePage.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (!isSettingUpPageSpinner) {
                    updateEpisodeList();
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        castManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        recyclerMore = findViewById(R.id.result_more_watch);
        recyclerCast = findViewById(R.id.result_cast);
        recyclerEpisodes = findViewById(R.id.result_episodes);
        movie_title = findViewById(R.id.result_title);
        movie_date = findViewById(R.id.result_date);
        movie_time = findViewById(R.id.result_time);
        movie_genre = findViewById(R.id.result_genre);

        movie_rank = findViewById(R.id.result_rank);
        result_back = findViewById(R.id.result_back);
        rating_bar = findViewById(R.id.rating_bar_activity_movie_rating);
        movie_adult = findViewById(R.id.result_adult);
        movie_description = findViewById(R.id.result_des);
        wait = findViewById(R.id.wait);
        result_finish_loading = findViewById(R.id.result_finish_loading);
        result_series_parent = findViewById(R.id.result_serie_parent);

        bookMark = findViewById(R.id.linear_layout_activity_movie_my_list);
        bookMark1 = findViewById(R.id.linear_layout_activity_movie_my_list1);
        bSignal = findViewById(R.id.linear_layout_movie_activity_help);
        bShare = findViewById(R.id.linear_layout_movie_activity_share);


        movie_poster = findViewById(R.id.result_poster);
        movie_cover = findViewById(R.id.result_cover);
        urlD = getIntent().getExtras().getString("KEY_DETAILS_URI");
        KEY_DETAILS_DATE = getIntent().getExtras().getString("KEY_DETAILS_DATE");
        KEY_DETAILS_RANK = getIntent().getExtras().getString("KEY_DETAILS_RANK");
        KEY_DETAILS_QUALITY = getIntent().getExtras().getString("KEY_DETAILS_QUALITY");
        KEY_DETAILS_TYPE = getIntent().getExtras().getString("KEY_DETAILS_TYPE");

        bTrailer = findViewById(R.id.linear_layout_movie_activity_trailer);

        movie_date.setText(KEY_DETAILS_DATE);

        if (!KEY_DETAILS_RANK.isEmpty()) {
            float a = Float.parseFloat(KEY_DETAILS_RANK);
            float b = a / 2;
            rating_bar.setRating(b);
        }

        bTrailer.setOnClickListener(v -> {

        });
        bShare.setOnClickListener(v -> {
            try {
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                shareIntent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name));
                String shareMessage = "\nLet me recommend you this application\n\n";
                shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" +getPackageName() + "\n\n";
                shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
                startActivity(Intent.createChooser(shareIntent, "choose one"));
            } catch (Exception e) {
                //e.toString();
            }
        });

        bookMark.setOnClickListener(view -> {
            bookMark1.setVisibility(View.VISIBLE);
            bookMark.setVisibility(View.GONE);

            FavoriteModel favoriteModel = new FavoriteModel();
            favoriteModel.setTitle(title);
            favoriteModel.setType(KEY_DETAILS_TYPE);
            favoriteModel.setDate(KEY_DETAILS_DATE);
            favoriteModel.setRank(KEY_DETAILS_RANK);
            favoriteModel.setQuality(KEY_DETAILS_QUALITY);
            favoriteModel.setPoster(poster);
            favoriteModel.setStream(urlD);

            AsyncTask.execute(new Runnable() {
                @Override
                public void run() {
                    TimeDatabase timeDatabase = TimeDatabase.getAppDatabase(MainActivitySeriesDetails.this);
                    FavoriteDatabase favoriteDatabase = FavoriteDatabase.getAppDatabase(MainActivitySeriesDetails.this);
                    favoriteDatabase.favoriteDao().insert(favoriteModel);
                    MainActivitySeriesDetails.this.runOnUiThread(new Runnable() {
                        public void run() {
                            Toast.makeText(MainActivitySeriesDetails.this, "تمت إضافة الى المفضلة", Toast.LENGTH_SHORT).show();
                        }
                    });

                }
            });

        });


        bookMark1.setOnClickListener(v -> {

            bookMark.setVisibility(View.VISIBLE);
            bookMark1.setVisibility(View.GONE);

            AsyncTask.execute(new Runnable() {
                @Override
                public void run() {
                    TimeDatabase timeDatabase = TimeDatabase.getAppDatabase(MainActivitySeriesDetails.this);
                    FavoriteDatabase favoriteDatabase = FavoriteDatabase.getAppDatabase(MainActivitySeriesDetails.this);
                    favoriteDatabase.favoriteDao().deleteFavorite(urlD);
                    MainActivitySeriesDetails.this.runOnUiThread(new Runnable() {
                        public void run() {
                            Toast.makeText(MainActivitySeriesDetails.this, "تمت الازالة من المفضلة", Toast.LENGTH_LONG).show();
                        }
                    });

                }
            });
        });
        result_back.setOnClickListener(view -> onBackPressed());

        bSignal.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_SENDTO);
            i.setType("text/plain");
            i.setData(Uri.parse("mailto:"));
            i.putExtra(Intent.EXTRA_EMAIL, new String[]{gmail});
            i.putExtra(Intent.EXTRA_SUBJECT, "تبليغ عن مشكلة بالمسلسل");
            i.putExtra(Intent.EXTRA_TEXT, "لقد واجهة مشكلة بهذا المسلسل فالرابط لايشتغل المرجو اصلاح المشكل و شكرا لكم . \n" +
                    "- اسم المسلسل :\n" + title);
            i.setPackage("com.google.android.gm");
            try {
                startActivity(Intent.createChooser(i, "Send mail..."));
            } catch (android.content.ActivityNotFoundException ex) {
                Toast.makeText(this, "There are no email clients installed.", Toast.LENGTH_SHORT).show();
            }
        });


        recyclerCast.setLayoutManager(castManager);
        adapterCast = new CastsAdapter(castsModels, MainActivitySeriesDetails.this);
        recyclerCast.setAdapter(adapterCast);

        recyclerMore.setLayoutManager(layoutManager);
        adapter = new HorAllMoviesAdapter(allMoviesModels, MainActivitySeriesDetails.this);
        recyclerMore.setAdapter(adapter);


        Content content = new Content();
        content.execute();




    }


    @SuppressLint("StaticFieldLeak")
    private class Content extends AsyncTask<Void, Void, Void> {


        @Override
        protected Void doInBackground(Void... voids) {

            try {

                URL google = null;
                try {
                    google = new URL(urlD);
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
                BufferedReader in = null;
                try {
                    assert google != null;
                    in = new BufferedReader(new InputStreamReader(google.openStream()));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                String input = null;
                StringBuilder stringBuffer = new StringBuilder();
                while (true) {
                    try {
                        assert in != null;
                        if ((input = in.readLine()) == null) break;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    stringBuffer.append(input);
                }
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                String htmlData = stringBuffer.toString();
                Document doc = Jsoup.parse(htmlData);

                Elements elementsTitle = doc.getElementsByClass("entry-title font-size-28 font-weight-bold text-white mb-0");
                Elements elementsPoster = doc.getElementsByClass("col-lg-3 col-md-4 text-center mb-5 mb-md-0");
                Elements elementsImdb = doc.getElementsByClass("font-size-16 text-white mt-2 d-flex align-items-center");
                Elements elementsRating = doc.getElementsByClass("font-size-16 text-white mt-2 d-flex align-items-center");
                Elements elementsAdult = doc.getElementsByClass("badge badge-pill badge-danger font-size-14 mr-3");
                Elements elementsLanguage = doc.getElementsByClass("font-size-16 text-white mt-2");
                Elements elementsGenre = doc.getElementsByClass("badge badge-pill badge-light ml-2");
                Elements elementsTrailer = doc.getElementsByClass("col-lg-2 col-md-3 col-sm-4 d-flex flex-column px-4 px-sm-0");
                Elements elementsDescription = doc.getElementsByClass("text-white font-size-18");
                Elements elementsInfo = doc.getElementsByClass("font-size-16 text-white mt-2");

                tags = doc.select("div.font-size-16.d-flex.align-items-center.mt-3 > a")
                        .text().replace("NETFLIX", "نتفليكس")
                        .replace(" ", " | ");

                int sizeInfo = elementsInfo.size();
                for (int i = 0; i < sizeInfo; i++) {
                    time = elementsInfo.eq(5).text().replace("مدة المسلسل : ", "");
                }

                title = elementsTitle.text();
                poster = elementsPoster.select("a").attr("href");
                imdb = elementsImdb.select("a").attr("href");
                rating = elementsRating.select("span.mx-2").text();
                adult = elementsAdult.text();
                language = elementsLanguage.text();
                genre = elementsGenre.text();
                trailer = elementsTrailer.select("a").attr("href");
                description = elementsDescription.text();


                Elements elementsCast = doc.getElementsByClass("col-lg-auto col-md-4 col-6 mb-12");

                int size = elementsCast.size();

                for (int i = 0; i < size; i++) {


                    String original_name = elementsCast.select("img")
                            .eq(i)
                            .attr("alt");
                    String details_path = elementsCast.select("a")
                            .eq(i)
                            .attr("href");

                    String profile_path = elementsCast.select("img")
                            .eq(i)
                            .attr("src");

                    castsModels.add(new CastsModel(original_name, profile_path, details_path));

                }


                episodesModels.clear();
                Elements elementsEpisodes = doc.getElementsByClass("bg-primary2 p-4 col-lg-4 col-md-6 col-12");
                Elements ElementTitle = doc.getElementsByClass("font-size-18 text-white mb-2");
                Elements ElementCover = doc.getElementsByClass("col-md-auto text-center pb-3 pb-md-0");


                int sizeE = elementsEpisodes.size();
                for (int i = 0; i < sizeE; i++) {

                    String titleEpisode = ElementTitle.eq(i).text();

                    String cover = ElementCover.select("a").select("img")
                            .eq(i)
                            .attr("src");

                    String stream = ElementTitle.select("a")
                            .eq(i)
                            .attr("href");


                    episodesModels.add(new EpisodesModel(title, titleEpisode, cover, stream));
                }

                Elements elementsMore = doc.getElementsByClass("entry-box entry-box-1");
                Elements ElementDate = doc.getElementsByClass("badge badge-pill badge-secondary ml-1");
                Elements ElementRank = doc.getElementsByClass("label rating");
                Elements ElementQuality = doc.getElementsByClass("label quality");
                Elements ElementType = doc.getElementsByClass("icn add-to-fav mr-4 private hide");

                int size1 = elementsMore.size();
                for (int i = 0; i < size1; i++) {

                    String title = elementsMore.select("div.entry-image")
                            .select("div.entry-image img")
                            .eq(i)
                            .attr("alt");
                    String poster = elementsMore.select("div.entry-image")
                            .select("div.entry-image img")
                            .eq(i)
                            .attr("data-src");
                    String stream = elementsMore.select("div.entry-image")
                            .select("a")
                            .eq(i)
                            .attr("href");

                    String type = ElementType
                            .select("a")
                            .eq(i)
                            .attr("data-type");
                    String date = ElementDate.eq(i)
                            .text();
                    String rank = ElementRank.eq(i)
                            .text();
                    String quality = ElementQuality.eq(i)
                            .text();

                    allMoviesModels.add(new AllMoviesModel(title, type, date, rank, quality, poster, stream, "0"));
                }


            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @SuppressLint("NotifyDataSetChanged")
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            movie_title.setText(title);
            movie_description.setText(description);
            movie_adult.setText(adult);
            movie_rank.setText(rating);
            movie_time.setText(time);
            movie_genre.setText(tags);

            AsyncTask.execute(new Runnable() {
                @Override
                public void run() {
                    FavoriteDatabase favoriteDatabase = FavoriteDatabase.getAppDatabase(MainActivitySeriesDetails.this);
                    checkFavorite = favoriteDatabase.favoriteDao().checkFavorite(urlD);

                    MainActivitySeriesDetails.this.runOnUiThread(new Runnable()
                    {
                        public void run()
                        {
                            if (checkFavorite == 0) {

                                bookMark1.setVisibility(View.GONE);
                                bookMark.setVisibility(View.VISIBLE);

                            } else {

                                bookMark1.setVisibility(View.VISIBLE);
                                bookMark.setVisibility(View.GONE);
                            }
                        }
                    });

                }
            });

            if(poster!=null){
                Uri uri = Uri.parse(poster);
                String token = uri.getLastPathSegment();
                Picasso.get()
                        .load(helper.getUrlImage() + "/thumb/1920x600/uploads/" + token)
                        .into(movie_cover);
            }

            Picasso.get()
                    .load(poster)
                    .into(movie_poster);




            adapterCast.notifyDataSetChanged();

            masterEpisodesList.clear();
            masterEpisodesList.addAll(episodesModels);
            setupPageSpinner(masterEpisodesList.size(), spinnerEpisodeSort.getSelectedItemPosition() == 0);
            updateEpisodeList();

            result_series_parent.setVisibility(View.VISIBLE);
            recyclerEpisodes.setLayoutManager(new LinearLayoutManager(MainActivitySeriesDetails.this, LinearLayoutManager.VERTICAL, false));
            episodesAdapter = new EpisodesAdapter(episodesModels, MainActivitySeriesDetails.this);
            recyclerEpisodes.setAdapter(episodesAdapter);
            adapter.notifyDataSetChanged();
            result_finish_loading.setVisibility(View.VISIBLE);
            wait.setVisibility(View.GONE);

        }
    }

    @SuppressLint("StaticFieldLeak")
    private class Episodes extends AsyncTask<Void, Void, Void> {


        @Override
        protected Void doInBackground(Void... voids) {

            try {
                String url = urlD;

                episodesModels.clear();
                doc = Jsoup.connect(url).userAgent("Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:25.0) Gecko/20100101 Firefox/25.0").get();
                Elements elementsEpisodes = doc.getElementsByClass("bg-primary2 p-4 col-lg-4 col-md-6 col-12");
                Elements ElementTitle = doc.getElementsByClass("font-size-18 text-white mb-2");
                Elements ElementCover = doc.getElementsByClass("col-md-auto text-center pb-3 pb-md-0");


                int size1 = elementsEpisodes.size();
                for (int i = 0; i < size1; i++) {

                    String titleEpisode = ElementTitle.eq(i).text();

                    String cover = ElementCover.select("a").select("img")
                            .eq(i)
                            .attr("src");

                    String stream = ElementTitle.select("a")
                            .eq(i)
                            .attr("href");


                    episodesModels.add(new EpisodesModel(title, titleEpisode, cover, stream));
                }


            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @SuppressLint("NotifyDataSetChanged")
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);


            masterEpisodesList.clear();
            masterEpisodesList.addAll(episodesModels);
            setupPageSpinner(masterEpisodesList.size(), spinnerEpisodeSort.getSelectedItemPosition() == 0);
            updateEpisodeList();

            result_series_parent.setVisibility(View.VISIBLE);
            recyclerEpisodes.setLayoutManager(new LinearLayoutManager(MainActivitySeriesDetails.this, LinearLayoutManager.VERTICAL, false));
            episodesAdapter = new EpisodesAdapter(episodesModels, MainActivitySeriesDetails.this);
            recyclerEpisodes.setAdapter(episodesAdapter);


        }
    }


    private void setupPageSpinner(int totalEpisodes, boolean isAscending) {
        isSettingUpPageSpinner = true;
        List<String> pageOptions = new ArrayList<>();
        int numPages = (totalEpisodes + 24) / 25;
        for (int i = 0; i < numPages; i++) {
            int start, end;
            if (isAscending) {
                start = i * 25 + 1;
                end = Math.min((i + 1) * 25, totalEpisodes);
                pageOptions.add(start + " - " + end);
            } else {
                start = totalEpisodes - (i * 25);
                end = Math.max(totalEpisodes - ((i + 1) * 25) + 1, 1);
                pageOptions.add(start + " - " + end);
            }
        }
        if (pageOptions.isEmpty()) {
            pageOptions.add("لا توجد حلقات");
        }
        ArrayAdapter<String> pageAdapter = new ArrayAdapter<>(this, R.layout.spinner_item, pageOptions);
        pageAdapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        spinnerEpisodePage.setAdapter(pageAdapter);
        isSettingUpPageSpinner = false;
    }

    private void updateEpisodeList() {
        if (masterEpisodesList.isEmpty()) {
            episodesModels.clear();
            if (episodesAdapter != null) {
                episodesAdapter.notifyDataSetChanged();
            }
            return;
        }

        boolean isAscending = spinnerEpisodeSort.getSelectedItemPosition() == 0;
        int selectedPage = spinnerEpisodePage.getSelectedItemPosition();
        if (selectedPage < 0) selectedPage = 0;

        int totalEpisodes = masterEpisodesList.size();

        List<EpisodesModel> sortedList = new ArrayList<>(masterEpisodesList);
        if (!isAscending) {
            java.util.Collections.reverse(sortedList);
        }

        int startIndex = selectedPage * 25;
        int endIndex = Math.min(startIndex + 25, totalEpisodes);

        episodesModels.clear();
        if (startIndex < sortedList.size()) {
            episodesModels.addAll(sortedList.subList(startIndex, endIndex));
        }

        if (episodesAdapter != null) {
            episodesAdapter.notifyDataSetChanged();
        }
    }


    @Override
    public void onResume() {
        super.onResume();

        Episodes episodes = new Episodes();
        episodes.execute();

    }

}