package com.robben.mands.Ui;


import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.robben.mands.R;
import com.robben.mands.Utils.Helper;


import org.json.JSONArray;
import org.json.JSONObject;


@SuppressLint("CustomSplashScreen")
public class MainActivitySplashScreen extends AppCompatActivity {
    Helper preferenceHelper;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_splash_screen);

        progressBar = findViewById(R.id.customProgress);


        preferenceHelper = new Helper(this);



        if (!isNetworkConnected()) {
            noInternet();
            return;

        }else{
            getData();

        }


    }


    private void getData() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, "https://devabdeljalil.github.io/client/aflam.json",
                response -> {

                    try {
                        JSONArray admob = response.getJSONArray("data");

                        for (int i = 0; i < admob.length(); i++) {
                            JSONObject object = admob.getJSONObject(i);

                            String adsInterAdmob = object.getString("AdmobInterstitial");
                            String adsNativeAdmob = object.getString("AdmobNative");
                            String adsBannerAdmob = object.getString("AdmobBanner");

                            String adsInterFace = object.getString("FaceInterstitial");
                            String adsNativeFace = object.getString("FaceNative");
                            String adsBannerFace = object.getString("FaceBanner");


                            String adsUnityGame = object.getString("UnityGame");
                            String adsUnityInterstitial = object.getString("UnityInterstitial");
                            String adsUnityBanner = object.getString("UnityBanner");

                            String adsApplovinInterstitial = object.getString("ApplovinInterstitial");
                            String adsApplovinBanner = object.getString("ApplovinBanner");


                            String adsApplovinInterstitialMax = object.getString("ApplovinInterstitialMax");
                            String adsApplovinBannerMax = object.getString("ApplovinBannerMax");
                            String adsApplovinNativeMax = object.getString("ApplovinNativeMax");

                            String adsIronInterstitial = object.getString("IronInterstitial");
                            String adsIronBanner = object.getString("IronBanner");

                            String UrlDefault = object.getString("UrlDefault");
                            String UrlImage = object.getString("UrlImage");

                            String adsSwitch ="stop";
                          // String adsSwitch = object.getString("Switch");


                            preferenceHelper.putInterAdmob(adsInterAdmob);
                            preferenceHelper.putNativeAdmob(adsNativeAdmob);
                            preferenceHelper.putBannerAdmob(adsBannerAdmob);

                            preferenceHelper.putInterFace(adsInterFace);
                            preferenceHelper.putNativeFace(adsNativeFace);
                            preferenceHelper.putBannerFace(adsBannerFace);

                            preferenceHelper.putUnityGame(adsUnityGame);
                            preferenceHelper.putUnityInterstitial(adsUnityInterstitial);
                            preferenceHelper.putUnityBanner(adsUnityBanner);

                            preferenceHelper.putApplovinInterstitial(adsApplovinInterstitial);
                            preferenceHelper.putApplovinBanner(adsApplovinBanner);

                            preferenceHelper.putMaxInterstitial(adsApplovinInterstitialMax);
                            preferenceHelper.putMaxBanner(adsApplovinBannerMax);
                            preferenceHelper.putMaxNative(adsApplovinNativeMax);

                            preferenceHelper.putIronInterstitial(adsIronInterstitial);
                            preferenceHelper.putIronBanner(adsIronBanner);

                            preferenceHelper.putSwitch(adsSwitch);

                            preferenceHelper.putUrlDefault(UrlDefault);
                            preferenceHelper.putUrlImage(UrlImage);

                        }



                        final int oneMin = 5 * 1000;
                        new CountDownTimer(oneMin, 1000) {
                            public void onTick(long millisUntilFinished) {

                                long finishedSeconds = oneMin - millisUntilFinished;
                                int total = (int) (((float) finishedSeconds / (float) oneMin) * 100.0);
                                progressBar.setProgress(total);


                            }

                            public void onFinish() {
                                Intent intent = new Intent(MainActivitySplashScreen.this, MainActivity.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                                startActivity(intent);
                                finish();
                            }
                        }.start();

                    } catch (Exception e) {
                        e.printStackTrace();

                        Toast.makeText(this,"هناك خطأ ما", Toast.LENGTH_LONG).show();

                    }

                }, error -> Log.e("VOLLEY", "ERROR")
        );

        jsonObjectRequest.setShouldCache(false);
        requestQueue.add(jsonObjectRequest);

    }

    private boolean isNetworkConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        return cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo().isConnected();

    }

    private void noInternet() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setCancelable(false)
                .setMessage("لا يوجد إنترنت ، الرجاء الاتصال بالشبكة!")
                .setNeutralButton("خروج", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        finish();
                    }
                });
        Dialog dialog = builder.create();
        dialog.show();
    }

}