package com.robben.mands.Utils;
import android.content.Context;
import android.content.SharedPreferences;

public class Helper {


    private final String INTER_ADMOB = "inter_admob";
    private final String BANNER_ADMOB = "banner_admob";
    private final String NATIVE_ADMOB = "native_admob";

    private final String INTER_FACE = "inter_face";
    private final String NATIVE_FACE = "native_face";
    private final String BANNER_FACE = "banner_face";

    private final String UNITY_GAME = "unity_game";
    private final String BANNER_UNITY = "banner_unity";
    private final String INTER_UNITY = "inter_unity";

    private final String INTER_APPLOVIN = "inter_applovin";
    private final String BANNER_APPLOVIN = "banner_applovin";

    private final String INTER_MAX = "inter_max";
    private final String BANNER_MAX = "banner_max";
    private final String NATIVE_MAX = "native_max";

    private final String INTER_IRON = "inter_iron";
    private final String BANNER_IRON = "banner_iron";


    private final String TEXT= "text";
    private final String URL_DEFAULT= "url_default";
    private final String URL_IMAGE= "url_image";

    private final String SWITCH = "switch";
    private final String COUNT = "count";



    SharedPreferences app_prefs;
    Context context;

    public Helper(Context context) {
        app_prefs = context.getSharedPreferences("shared",
                Context.MODE_PRIVATE);
        this.context = context;
    }



    public void putInterAdmob(String text) {
        SharedPreferences.Editor edit = app_prefs.edit();
        edit.putString(INTER_ADMOB, text);
        edit.apply();
    }

    public String getInterAdmob() {

        return app_prefs.getString(INTER_ADMOB, "");
    }



    public void putBannerAdmob(String text) {
        SharedPreferences.Editor edit = app_prefs.edit();
        edit.putString(BANNER_ADMOB, text);
        edit.apply();
    }

    public String getBannerAdmob() {

        return app_prefs.getString(BANNER_ADMOB, "");
    }


    public void putNativeAdmob(String text) {
        SharedPreferences.Editor edit = app_prefs.edit();
        edit.putString(NATIVE_ADMOB, text);
        edit.apply();
    }

    public String getNativeAdmob() {

        return app_prefs.getString(NATIVE_ADMOB, "");
    }


    public void putInterFace(String text) {
        SharedPreferences.Editor edit = app_prefs.edit();
        edit.putString(INTER_FACE, text);
        edit.apply();
    }

    public String getInterFace() {

        return app_prefs.getString(INTER_FACE, "");
    }


    public void putNativeFace(String text) {
        SharedPreferences.Editor edit = app_prefs.edit();
        edit.putString(NATIVE_FACE, text);
        edit.apply();
    }

    public String getNativeFace() {

        return app_prefs.getString(NATIVE_FACE, "");
    }


    public void putBannerFace(String text) {
        SharedPreferences.Editor edit = app_prefs.edit();
        edit.putString(BANNER_FACE, text);
        edit.apply();
    }

    public String getBannerFace() {

        return app_prefs.getString(BANNER_FACE, "");
    }


    public void putUnityGame(String text) {
        SharedPreferences.Editor edit = app_prefs.edit();
        edit.putString(UNITY_GAME, text);
        edit.apply();
    }

    public String getUnityGame() {

        return app_prefs.getString(UNITY_GAME, "");
    }

    public void putUnityInterstitial(String text) {
        SharedPreferences.Editor edit = app_prefs.edit();
        edit.putString(INTER_UNITY, text);
        edit.apply();
    }

    public String getUnityInterstitial() {

        return app_prefs.getString(INTER_UNITY, "");
    }

    public void putUnityBanner(String text) {
        SharedPreferences.Editor edit = app_prefs.edit();
        edit.putString(BANNER_UNITY, text);
        edit.apply();
    }

    public String getUnityBanner() {

        return app_prefs.getString(BANNER_UNITY, "");
    }

    public void putApplovinInterstitial(String text) {
        SharedPreferences.Editor edit = app_prefs.edit();
        edit.putString(INTER_APPLOVIN, text);
        edit.apply();
    }
    public String getApplovinInterstitial() {

        return app_prefs.getString(INTER_APPLOVIN, "");
    }

    public void putApplovinBanner(String text) {
        SharedPreferences.Editor edit = app_prefs.edit();
        edit.putString(BANNER_APPLOVIN, text);
        edit.apply();
    }

    public String getApplovinBanner() {

        return app_prefs.getString(BANNER_APPLOVIN, "");
    }
    public void putMaxInterstitial(String text) {
        SharedPreferences.Editor edit = app_prefs.edit();
        edit.putString(INTER_MAX, text);
        edit.commit();
    }
    public String getMaxInterstitial() {

        return app_prefs.getString(INTER_MAX, "");
    }

    public void putMaxBanner(String text) {
        SharedPreferences.Editor edit = app_prefs.edit();
        edit.putString(BANNER_MAX, text);
        edit.commit();
    }

    public String getMaxBanner() {

        return app_prefs.getString(BANNER_MAX, "");
    }

    public void putMaxNative(String text) {
        SharedPreferences.Editor edit = app_prefs.edit();
        edit.putString(NATIVE_MAX, text);
        edit.commit();
    }

    public String getMaxNative() {

        return app_prefs.getString(NATIVE_MAX, "");
    }

    public void putIronInterstitial(String text) {
        SharedPreferences.Editor edit = app_prefs.edit();
        edit.putString(INTER_IRON, text);
        edit.commit();
    }
    public String getIronInterstitial() {

        return app_prefs.getString(INTER_IRON, "");
    }

    public void putIronBanner(String text) {
        SharedPreferences.Editor edit = app_prefs.edit();
        edit.putString(BANNER_IRON, text);
        edit.commit();
    }

    public String getIronBanner() {

        return app_prefs.getString(BANNER_IRON, "");
    }





    public void putSwitch(String text) {
        SharedPreferences.Editor edit = app_prefs.edit();
        edit.putString(SWITCH, text);
        edit.apply();
    }


    public String getSwitch() {

        return app_prefs.getString(SWITCH, "");
    }

    public void putCount(String text) {
        SharedPreferences.Editor edit = app_prefs.edit();
        edit.putString(COUNT, text);
        edit.apply();
    }

    public String getCount() {

        return app_prefs.getString(COUNT, "");
    }

    public void putText(String text) {
        SharedPreferences.Editor edit = app_prefs.edit();
        edit.putString(TEXT, text);
        edit.apply();
    }


    public String getText() {

        return app_prefs.getString(TEXT, "");
    }

    public void putUrlDefault(String text) {
        SharedPreferences.Editor edit = app_prefs.edit();
        edit.putString(URL_DEFAULT, text);
        edit.apply();
    }


    public String getUrlDefault() {

        return app_prefs.getString(URL_DEFAULT, "");
    }

    public void putUrlImage(String text) {
        SharedPreferences.Editor edit = app_prefs.edit();
        edit.putString(URL_IMAGE, text);
        edit.apply();
    }


    public String getUrlImage() {

        return app_prefs.getString(URL_IMAGE, "");
    }
}