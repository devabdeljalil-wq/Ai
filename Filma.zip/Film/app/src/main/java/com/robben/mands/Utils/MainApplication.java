package com.robben.mands.Utils;

import android.app.Application;



/**
 * Created by Mezioud on  16,janvier,2022.
 */
public class MainApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();



    }



}