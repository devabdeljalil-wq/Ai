package com.robben.mands.Utils;

import android.app.Activity;
import android.util.DisplayMetrics;

/**
 * Created by Mezioud on  21,décembre,2021.
 */
public class Utility {

    public static int calculateNoOfColumns(Activity activity) {
        DisplayMetrics displayMetrics = activity.getResources().getDisplayMetrics();
        float screenWidthDp = displayMetrics.widthPixels / displayMetrics.density;
        return (int) (screenWidthDp / 120 + 0.5);
    }
}